package Lista.compra.models

import com.google.firebase.Timestamp

// En ShoppingItem.kt
data class ShoppingItem(
    var id: String = "",
    var text: String = "",
    var completed: Boolean = false,
    var listId: String = "",
    var userId: String = "",
    var addedBy: String = "",
    var purchasedBy: String = "",
    var purchasedAt: Timestamp? = null,
    var createdAt: Timestamp = Timestamp.now(),
    var category: ProductCategory? = null,
    var price: Double? = null,
){
    constructor() : this(
        id = "",
        text = "",
        completed = false,
        listId = "",
        userId = "",
        addedBy = "",
        purchasedBy = "",
        purchasedAt = null,
        createdAt = com.google.firebase.Timestamp.now(),
        category = null,
        price = null
    )
}

enum class ProductCategory {
    FRUITS_VEGETABLES,
    MEAT,
    FISH,
    DAIRY,
    BAKERY,
    CLEANING,
    BEVERAGES,
    PANTRY,
    CONGELADOS,
    SNACKS,
    CANNED,
    GRAINS_PASTA,
    SAUCES_SPICES,
    PERSONAL_CARE,
    PET,
    BABY,
    OTHER,
    COMPRADO
}