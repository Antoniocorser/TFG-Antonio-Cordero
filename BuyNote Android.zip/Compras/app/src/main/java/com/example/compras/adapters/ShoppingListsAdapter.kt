package Lista.compra.adapters

import android.content.Context
import android.widget.ArrayAdapter
import Lista.compra.models.ShoppingList

class ShoppingListsAdapter(
    context: Context,
    private val onListSelected: (ShoppingList) -> Unit
) : ArrayAdapter<ShoppingList>(context, android.R.layout.simple_spinner_item, mutableListOf()) {

    private val shoppingLists = mutableListOf<ShoppingList>()

    override fun getItem(position: Int): ShoppingList? = shoppingLists.getOrNull(position)

    override fun getCount(): Int = shoppingLists.size
}
