package Lista.compra.adapters

import Lista.compra.R
import Lista.compra.models.ProductCategory
import Lista.compra.models.ShoppingItem
import android.app.AlertDialog
import android.content.Context
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class ShoppingItemsAdapter(
    private val context: Context,
    private var items: List<ShoppingItem>,
    private val onItemChecked: (ShoppingItem, Boolean) -> Unit,
    private val onDeleteClick: (ShoppingItem) -> Unit,
    private val onItemClick: (ShoppingItem) -> Unit = {},
    private val getItemPrice: (String) -> Double? = { null },
    private var isSharedList: Boolean = false
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var showPurchaserInfo: Boolean = false
    val currentItems: List<ShoppingItem>
        get() = items

    private val displayItems = mutableListOf<Any>()

    private val categoryNames = mapOf(
        ProductCategory.FRUITS_VEGETABLES to "Frutas y Verduras",
        ProductCategory.MEAT to "Carnes",
        ProductCategory.FISH to "Pescados",
        ProductCategory.DAIRY to "Lácteos",
        ProductCategory.BAKERY to "Panadería",
        ProductCategory.CLEANING to "Limpieza",
        ProductCategory.BEVERAGES to "Bebidas",
        ProductCategory.PANTRY to "Despensa",
        ProductCategory.OTHER to "Otros",
        ProductCategory.COMPRADO to "Comprado",
        ProductCategory.CONGELADOS to "Congelados",
        ProductCategory.SNACKS to "Snacks",
        ProductCategory.CANNED to "Conservas",
        ProductCategory.GRAINS_PASTA to "Arroces y Pasta",
        ProductCategory.SAUCES_SPICES to "Salsas y Especias",
        ProductCategory.PERSONAL_CARE to "Cuidado Personal",
        ProductCategory.PET to "Mascotas",
        ProductCategory.BABY to "Bebé"
    )

    init {
        groupItemsByCategory()
    }

    private fun groupItemsByCategory() {
        displayItems.clear()

        // Separar items completados y no completados
        val completedItems = items.filter { it.completed }
        val pendingItems = items.filter { !it.completed }

        // Agrupar items pendientes por categoría
        val groupedPending = pendingItems.groupBy { it.category ?: ProductCategory.OTHER }
            .toSortedMap(compareBy { it.ordinal })

        // Añadir categorías de items pendientes
        groupedPending.forEach { (category, itemsInCategory) ->
            if (itemsInCategory.isNotEmpty()) {
                displayItems.add(category)
                displayItems.addAll(itemsInCategory.sortedBy { it.text })
            }
        }

        // Añadir categoría "Comprado" al final con sus items
        if (completedItems.isNotEmpty()) {
            displayItems.add(ProductCategory.COMPRADO)
            displayItems.addAll(completedItems.sortedBy { it.text })
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (displayItems[position]) {
            is ProductCategory -> TYPE_HEADER
            else -> TYPE_ITEM
        }
    }

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textView: TextView = itemView.findViewById(R.id.item_text)
        val checkbox: CheckBox = itemView.findViewById(R.id.item_checkbox)
        val deleteButton: ImageButton = itemView.findViewById(R.id.delete_button)
        val purchaserInfo: TextView? = itemView.findViewById(R.id.purchaser_info)
        val addedByInfo: TextView? = itemView.findViewById(R.id.added_by_info)
        val priceInfo: TextView? = itemView.findViewById(R.id.price_info)

        init {
            // Verificar que las vistas principales existen
            if (textView == null) throw IllegalStateException("item_text not found in layout")
            if (checkbox == null) throw IllegalStateException("item_checkbox not found in layout")
            if (deleteButton == null) throw IllegalStateException("delete_button not found in layout")
        }

        fun bind(item: ShoppingItem) {
            checkbox.setOnCheckedChangeListener(null)
            checkbox.isChecked = item.completed
            textView.text = item.text
            updateTextAppearance(item.completed)

            // MOSTRAR información del precio si existe
            updatePriceInfo(item)

            // MOSTRAR información del comprador/añadido SOLO en listas compartidas
            updatePurchaserInfo(item)

            checkbox.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked && !item.completed) {
                    // Si se está marcando como completado, mostrar diálogo de precio
                    val context = itemView.context
                    if (context is AppCompatActivity) {
                        showPriceDialog(context, item) { price ->
                            // VERIFICAR SI EL USUARIO CANCELÓ
                            if (price == null) {
                                // USUARIO CANCELÓ - revertir el checkbox
                                checkbox.isChecked = false
                                return@showPriceDialog
                            }

                            // Actualizar el item con el precio
                            val updatedItem = item.copy(
                                completed = true,
                                category = ProductCategory.COMPRADO,
                                price = price
                            )

                            // Actualizar UI inmediatamente
                            updateTextAppearance(true)
                            updatePriceInfo(updatedItem)
                            updatePurchaserInfo(updatedItem)

                            onItemChecked(updatedItem, true)
                        }
                    }
                } else {
                    // Si se está desmarcando, actualizar normalmente
                    val updatedItem = item.copy(
                        completed = isChecked,
                        category = if (isChecked) ProductCategory.COMPRADO else determineCategory(item.text),
                        price = if (!isChecked) null else item.price // Limpiar precio si se desmarca
                    )

                    // Actualizar UI inmediatamente
                    updateTextAppearance(isChecked)
                    updatePriceInfo(updatedItem)
                    updatePurchaserInfo(updatedItem)

                    onItemChecked(updatedItem, isChecked)
                }
            }

            deleteButton.setOnClickListener {
                onDeleteClick(item)
            }

            itemView.setOnClickListener {
                onItemClick(item)
            }
        }

        // Función para mostrar el diálogo de precio desde el adaptador
// Función para mostrar el diálogo de precio desde el adaptador - CORREGIDA
        private fun showPriceDialog(context: AppCompatActivity, item: ShoppingItem, onPriceEntered: (Double?) -> Unit) {
            val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_price_input, null)
            val priceEditText = dialogView.findViewById<EditText>(R.id.price_edit_text)
            val messageText = dialogView.findViewById<TextView>(R.id.message_text)

            messageText.text = "Introduce el precio para \"${item.text}\":"

            val dialog = AlertDialog.Builder(context)
                .setTitle("Precio del Producto")
                .setView(dialogView)
                .setPositiveButton("Aceptar") { dialogInterface, _ ->
                    val priceText = priceEditText.text.toString().trim()
                    val price = if (priceText.isNotEmpty()) {
                        try {
                            priceText.toDouble()
                        } catch (e: NumberFormatException) {
                            0.0
                        }
                    } else {
                        0.0 // Precio 0 si no se introduce nada
                    }
                    onPriceEntered(price)
                    dialogInterface.dismiss()
                }
                .setNegativeButton("Cancelar") { dialogInterface, _ ->
                    onPriceEntered(null) // Enviar null para indicar cancelación
                    dialogInterface.dismiss()
                }
                .setNeutralButton("Sin Precio (0€)") { dialogInterface, _ ->
                    onPriceEntered(0.0)
                    dialogInterface.dismiss()
                }
                .setOnCancelListener {
                    // Manejar cuando el usuario pulsa fuera del diálogo o back button
                    onPriceEntered(null)
                }
                .create()

            dialog.show()
        }

        // Función para actualizar la información del precio en la UI
        private fun updatePriceInfo(item: ShoppingItem) {
            priceInfo?.let { priceView ->
                if (item.completed && item.price != null) {
                    val price = item.price!!
                    val priceText = if (price == 0.0) {
                        "0.00 € (sin precio)"
                    } else {
                        "%.2f €".format(price)
                    }

                    priceView.text = priceText
                    priceView.setTextColor(
                        ContextCompat.getColor(
                            context,
                            if (price == 0.0) R.color.dark_gray else R.color.success_green
                        )
                    )
                    priceView.visibility = View.VISIBLE
                } else {
                    priceView.visibility = View.GONE
                }
            }
        }

        private fun updatePurchaserInfo(item: ShoppingItem) {
            val currentUserEmail = Firebase.auth.currentUser?.email ?: ""

            // SOLO mostrar información en listas compartidas
            if (!isSharedList) {
                purchaserInfo?.visibility = View.GONE
                addedByInfo?.visibility = View.GONE
                return
            }

            // Mostrar información del comprador solo si está completado y en lista compartida
            if (item.completed && item.purchasedBy.isNotEmpty()) {
                val purchaserName = if (item.purchasedBy == currentUserEmail) {
                    "Tí"
                } else {
                    item.purchasedBy.split("@").firstOrNull() ?: item.purchasedBy
                }
                purchaserInfo?.text = "Comprado por: $purchaserName"
                purchaserInfo?.visibility = View.VISIBLE
                purchaserInfo?.setTextColor(ContextCompat.getColor(context, R.color.success_green))
            } else {
                purchaserInfo?.visibility = View.GONE
            }

            // Mostrar quién añadió el ítem solo en listas compartidas
            if (item.addedBy.isNotEmpty() && item.addedBy != currentUserEmail) {
                val addedByName = item.addedBy.split("@").firstOrNull() ?: item.addedBy
                addedByInfo?.text = "Añadido por: $addedByName"
                addedByInfo?.visibility = View.VISIBLE
                addedByInfo?.setTextColor(ContextCompat.getColor(context, R.color.dark_gray))
            } else if (item.addedBy == currentUserEmail) {
                addedByInfo?.text = "Añadido por: Tí"
                addedByInfo?.visibility = View.VISIBLE
                addedByInfo?.setTextColor(ContextCompat.getColor(context, R.color.dark_gray))
            } else {
                addedByInfo?.visibility = View.GONE
            }
        }

        private fun updateTextAppearance(isCompleted: Boolean) {
            if (isCompleted) {
                textView.paintFlags = textView.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                textView.setTextColor(ContextCompat.getColor(context, R.color.dark_gray))
                textView.alpha = 0.7f
            } else {
                textView.paintFlags = textView.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                textView.setTextColor(ContextCompat.getColor(context, R.color.black))
                textView.alpha = 1.0f
            }
        }

        private fun determineCategory(text: String): ProductCategory {
            // Lógica simplificada para determinar categoría
            val normalizedText = text.lowercase().trim()

            val categoryKeywords = mapOf(
                ProductCategory.FRUITS_VEGETABLES to listOf("manzana", "plátano", "naranja", "pera", "lechuga", "tomate"),
                ProductCategory.MEAT to listOf("pollo", "ternera", "cerdo", "filete"),
                ProductCategory.DAIRY to listOf("leche", "queso", "yogur", "mantequilla"),
                ProductCategory.BAKERY to listOf("pan", "bollo", "galleta", "tostada"),
            )

            categoryKeywords.forEach { (category, keywords) ->
                if (keywords.any { keyword -> normalizedText.contains(keyword) }) {
                    return category
                }
            }

            return ProductCategory.OTHER
        }
    }

    inner class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textView: TextView = itemView.findViewById(R.id.header_text)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_category_header, parent, false)
            HeaderViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_shopping_item, parent, false)
            ItemViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is HeaderViewHolder -> {
                val category = displayItems[position] as ProductCategory
                holder.textView.text = categoryNames[category] ?: "Sin categoría"

                // Cambiar color del header si es la categoría "Comprado"
                if (category == ProductCategory.COMPRADO) {
                    holder.textView.setTextColor(ContextCompat.getColor(context, R.color.success_green))
                    holder.textView.setBackgroundColor(ContextCompat.getColor(context, R.color.light_green))
                } else {
                    holder.textView.setTextColor(ContextCompat.getColor(context, R.color.dark_blue))
                    holder.textView.setBackgroundColor(ContextCompat.getColor(context, R.color.light_blue))
                }
            }
            is ItemViewHolder -> {
                val item = displayItems[position] as ShoppingItem
                holder.bind(item)
            }
        }
    }

    override fun getItemCount(): Int = displayItems.size

    fun updateData(newItems: List<ShoppingItem>, showPurchaserInfo: Boolean = false, isSharedList: Boolean = false) {
        this.items = newItems
        this.showPurchaserInfo = showPurchaserInfo
        this.isSharedList = isSharedList // Actualizar el estado de lista compartida
        groupItemsByCategory()
        notifyDataSetChanged()
    }

    // Función para actualizar precio de un item
    fun updateItemPrice(itemId: String, price: Double) {
        val item = currentItems.find { it.id == itemId }
        item?.price = price
        notifyDataSetChanged()
    }

    // Función para calcular el total automáticamente
    fun calculateTotal(): Double {
        return items.filter { it.completed }.sumOf { item ->
            item.price ?: 0.0
        }
    }

    // Función para obtener items comprados con precios
    fun getPurchasedItemsWithPrices(): List<ShoppingItem> {
        return items.filter { it.completed && (it.price ?: 0.0) >= 0 }
    }

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_ITEM = 1
    }
}