package Lista.compra

import com.journeyapps.barcodescanner.CaptureActivity

class CaptureActivityPortrait : CaptureActivity()