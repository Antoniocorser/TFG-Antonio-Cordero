package Lista.compra

import android.content.Context
import android.content.pm.ActivityInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.FragmentManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import androidx.fragment.app.commit
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.FirebaseFirestoreSettings

class MainActivity : AppCompatActivity(), AuthEmailFragment.AuthListener {
    private val auth = Firebase.auth
    private val db = Firebase.firestore
    private var authStateListener: FirebaseAuth.AuthStateListener? = null
    private var isOnline = true

    override fun onCreate(savedInstanceState: Bundle?) {
        // FORZAR TEMA CLARO ANTES DE CREAR LA ACTIVITY
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Forzar orientación vertical
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        // Configurar Firestore para persistencia offline
        setupFirestoreOffline()
        setupAuthListener()
        handleIntentExtras()
        checkNetworkConnection()

        if (savedInstanceState == null) {
            showInitialFragment()
        }
    }

    private fun setupFirestoreOffline() {
        try {
            val settings = FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .setCacheSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                .build()

            db.firestoreSettings = settings
            Log.d("Firestore", "Persistencia offline configurada")
        } catch (e: Exception) {
            Log.e("Firestore", "Error configurando persistencia offline: ${e.message}")
        }
    }

    private fun setupAuthListener() {
        authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            if (!isFinishing && !isDestroyed) {
                runOnUiThread {
                    if (firebaseAuth.currentUser == null) {
                        showAuthFragment()
                    } else {
                        showShoppingListFragment()
                    }
                }
            }
        }
    }

    private fun handleIntentExtras() {
        intent.extras?.let { extras ->
            if (extras.containsKey("listId")) {
                val listId = extras.getString("listId")
                listId?.let { openSharedList(it) }
            }
        }
    }

    private fun checkNetworkConnection() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val capabilities = connectivityManager.getNetworkCapabilities(network)

        val wasOnline = isOnline
        isOnline = capabilities != null &&
                (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))

        if (!isOnline && wasOnline) {
            showMessage("Modo offline activado. Los cambios se sincronizarán cuando recuperes la conexión.")
        } else if (isOnline && !wasOnline) {
            showMessage("Conexión recuperada. Sincronizando...")
            // Firestore se sincroniza automáticamente, no necesitamos notificar al fragment
        }
    }

    override fun onStart() {
        super.onStart()
        authStateListener?.let { auth.addAuthStateListener(it) }
        // Verificar conexión periódicamente
        startConnectionMonitoring()
    }

    override fun onAuthSuccess() {
        showShoppingListFragment()
    }

    override fun onStop() {
        super.onStop()
        authStateListener?.let { auth.removeAuthStateListener(it) }
        stopConnectionMonitoring()
    }

    private fun startConnectionMonitoring() {
        // Verificar conexión cada 3 segundos
        handler.postDelayed(connectionCheckRunnable, 3000)
    }

    private fun stopConnectionMonitoring() {
        handler.removeCallbacks(connectionCheckRunnable)
    }

    private val handler = android.os.Handler()
    private val connectionCheckRunnable = object : Runnable {
        override fun run() {
            checkNetworkConnection()
            handler.postDelayed(this, 5000) // Verificar cada 5 segundos
        }
    }

    private fun showInitialFragment() {
        if (auth.currentUser == null) {
            showAuthFragment()
        } else {
            showShoppingListFragment()
        }
    }

    private fun showAuthFragment() {
        if (!isFinishing && !isDestroyed && supportFragmentManager.isDestroyed.not()) {
            supportFragmentManager.commit {
                replace(R.id.fragment_container, AuthEmailFragment())
                // Limpiar el back stack para evitar volver atrás a la lista
                supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
            }
        }
    }

    private fun showShoppingListFragment() {
        if (!isFinishing && !isDestroyed && supportFragmentManager.isDestroyed.not()) {
            supportFragmentManager.commit {
                replace(R.id.fragment_container, ShoppingListFragment())
            }
        }
    }

    private fun showMessage(message: String) {
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG).show()
    }

    private fun openSharedList(listId: String) {
        val fragment = ShoppingListFragment().apply {
            arguments = Bundle().apply {
                putString("listId", listId)
            }
        }

        supportFragmentManager.commit {
            replace(R.id.fragment_container, fragment)
            addToBackStack(null)
        }
    }

    // Método para que los fragments verifiquen el estado de conexión
    fun isDeviceOnline(): Boolean {
        return isOnline
    }
}