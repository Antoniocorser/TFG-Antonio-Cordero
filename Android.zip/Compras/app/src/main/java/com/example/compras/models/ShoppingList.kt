package Lista.compra.models


data class ShoppingList(
    val name: String = "",
    val userId: String = "",
    val ownerEmail: String = "",
    val sharedWith: List<String> = emptyList(),
    val createdAt: com.google.firebase.Timestamp = com.google.firebase.Timestamp.now(),
    val purchaseInfo: Map<String, Any>? = null,
) {
    override fun toString(): String = name
}