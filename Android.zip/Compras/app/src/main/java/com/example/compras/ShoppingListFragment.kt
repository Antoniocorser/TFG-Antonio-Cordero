package Lista.compra

import Lista.compra.adapters.PaymentParticipantsAdapter
import android.Manifest
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import Lista.compra.adapters.ShoppingItemsAdapter
import Lista.compra.databinding.FragmentShoppingListBinding
import Lista.compra.models.ProductCategory
import Lista.compra.models.ShoppingItem
import Lista.compra.models.ShoppingList
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Rect
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.children
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ListenerRegistration
import com.google.zxing.integration.android.IntentIntegrator
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import retrofit2.HttpException
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import android.text.TextUtils
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView

class ShoppingListFragment : Fragment() {
    private lateinit var binding: FragmentShoppingListBinding
    private val auth = Firebase.auth
    private val db = Firebase.firestore
    private lateinit var itemsAdapter: ShoppingItemsAdapter
    private var currentListId: String? = null
    private var itemsListener: ListenerRegistration? = null
    private var listsListener: ListenerRegistration? = null
    private var listInfoListener: ListenerRegistration? = null
    private var selectedListType: ListType = ListType.MY_LISTS

    // Estructura para división de gastos
    data class ExpenseSplit(
        var participants: MutableList<String> = mutableListOf(),
        var expenses: MutableMap<String, Double> = mutableMapOf(),
        var totalAmount: Double = 0.0,
        var storeInfo: String = "",
        var date: String = ""
    )

    // Componentes de UI para información de la lista
    private lateinit var listInfoSection: LinearLayout
    private lateinit var priceInfoLayout: LinearLayout
    private lateinit var priceInfoText: TextView
    private lateinit var extraInfoLayout: LinearLayout
    private lateinit var extraInfoText: TextView
    private lateinit var extraInfoEditLabel: TextView

    // Mapa para almacenar observaciones de cada lista
    private var listObservations = mutableMapOf<String, String>()

    // Tipos de listas disponibles
    private enum class ListType {
        MY_LISTS, SHARED_LISTS
    }

    // Manejador de excepciones para corrutinas
    private val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        if (isAdded) {
            activity?.runOnUiThread {
                showError("Error inesperado: ${throwable.localizedMessage}")
                showProductNameDialog("")
            }
        }
    }

    // Configuración del servicio API para productos
    private val productApi: ProductApiService by lazy {
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl("https://world.openfoodfacts.org/api/v0/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ProductApiService::class.java)
    }

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 1001
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentShoppingListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (!isAdded) return

        // Inicializar componentes de UI
        initListInfoViews()
        setupUI()
        setupAdditionalButtons()
        setupAdapters()
        setupFirestoreListeners()
        setupElegantUI()

        // Configurar selectores y visibilidad de botones
        addListTypeSelector()
        updateSelectorChipColors()

        // Actualizar TODOS los botones
        updateShareButtonVisibility()
        updateCreateListButtonVisibility()
        updateSplitExpensesButtonVisibility()
        updateFABVisibility()
        updateFinalizePurchaseButtonVisibility()
        updateExtraInfoButtonVisibility()
        updateScanBarcodeButtonVisibility()

        // Configurar escáner de código de barras
        binding.scanBarcodeButton.setOnClickListener {
            if (currentListId == null || listsWithIds.none { it.first == currentListId }) {
                showError("Selecciona una lista primero")
                // Seleccionar automáticamente la primera lista disponible
                if (listsWithIds.isNotEmpty()) {
                    val firstListId = listsWithIds.first().first
                    currentListId = firstListId
                    loadItemsForList(firstListId)
                    updateListSelectionInUI(firstListId)
                    showMessage("Lista '${listsWithIds.first().second.name}' seleccionada automáticamente")
                    // Actualizar TODOS los botones después de seleccionar lista
                    updateFABVisibility()
                    updateSplitExpensesButtonVisibility()
                    updateFinalizePurchaseButtonVisibility()
                    updateExtraInfoButtonVisibility()
                    updateScanBarcodeButtonVisibility()
                }
                return@setOnClickListener
            }
            startBarcodeScan()
        }
    }

    // Actualizar visibilidad del botón de división de gastos
    private fun updateSplitExpensesButtonVisibility() {
        // Si no hay listas o no hay lista seleccionada, ocultar el botón
        if (listsWithIds.isEmpty() || currentListId == null || listsWithIds.none { it.first == currentListId }) {
            binding.splitExpensesButton.visibility = View.GONE
            return
        }

        val currentList = currentListId?.let { listId ->
            listsWithIds.find { it.first == listId }?.second
        }

        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        // Obtener las listas según el tipo seleccionado
        val relevantLists = when (selectedListType) {
            ListType.MY_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.userId == userId || list.ownerEmail == currentUserEmail
            }
            ListType.SHARED_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.sharedWith.contains(currentUserEmail) &&
                        !(list.userId == userId || list.ownerEmail == currentUserEmail)
            }
        }

        // Si estamos en "Compartidas conmigo" y no hay listas relevantes, ocultar el botón
        if (selectedListType == ListType.SHARED_LISTS && relevantLists.isEmpty()) {
            binding.splitExpensesButton.visibility = View.GONE
            return
        }

        val shouldShow = currentList?.let { list ->
            val isOwnedByMe = list.userId == userId || list.ownerEmail == currentUserEmail
            val isSharedWithMe = list.sharedWith.contains(currentUserEmail)
            val isSharedWithOthers = list.sharedWith.isNotEmpty()

            // Solo mostrar para listas compartidas (que yo compartí o me compartieron)
            val isSharedList = (isOwnedByMe && isSharedWithOthers) || (isSharedWithMe && !isOwnedByMe)

            // Si estamos en "Mis Listas", solo mostrar el botón si tengo listas propias
            if (selectedListType == ListType.MY_LISTS) {
                isSharedList && relevantLists.isNotEmpty()
            } else {
                // Si estamos en "Compartidas", mostrar normalmente
                isSharedList
            }
        } ?: false

        binding.splitExpensesButton.visibility = if (shouldShow) View.VISIBLE else View.GONE
    }

    // Actualizar la selección de lista en la interfaz
    private fun updateListSelectionInUI(listId: String) {
        binding.listsChipGroup.children.forEach { view ->
            if (view is Chip) {
                val isSelected = view.tag == listId
                view.isChecked = isSelected

                // Actualizar colores del chip según tipo y propiedad
                val currentList = listsWithIds.find { it.first == listId }?.second
                val currentUserEmail = auth.currentUser?.email ?: ""
                val isOwnedByMe = currentList?.userId == auth.currentUser?.uid ||
                        currentList?.ownerEmail == currentUserEmail
                val isSharedWithMe = currentList?.sharedWith?.contains(currentUserEmail) == true

                updateChipColors(view, isOwnedByMe, isSharedWithMe, isSelected)
            }
        }

        updateSplitExpensesButtonVisibility()
    }

    // Inicializar vistas de información de la lista
    private fun initListInfoViews() {
        listInfoSection = binding.listInfoSection
        priceInfoLayout = binding.priceInfoLayout
        priceInfoText = binding.priceInfoText
        extraInfoLayout = binding.extraInfoLayout
        extraInfoText = binding.extraInfoText
        extraInfoEditLabel = binding.extraInfoEditLabel

        // Configurar clic para editar información adicional
        extraInfoEditLabel.setOnClickListener {
            showSimpleExtraInfoDialog()
        }
    }

    // Configurar botones adicionales
    private fun setupAdditionalButtons() {
        binding.finalizePurchaseButton.setOnClickListener {
            showSimpleFinalizeDialog()
        }

        binding.splitExpensesButton.setOnClickListener {
            showSplitOptionsDialog()
        }

        binding.addExtraInfoButton.setOnClickListener {
            showObservationsDialog()
        }

        // Inicializar visibilidad de los botones
        updateFinalizePurchaseButtonVisibility()
        updateExtraInfoButtonVisibility()
        updateScanBarcodeButtonVisibility()
    }

    // Diálogo para ver observaciones (modo lectura)
    private fun showObservationsDialog() {
        val currentListId = currentListId ?: run {
            showError("Selecciona una lista primero")
            return
        }

        val currentObservations = listObservations[currentListId] ?: ""
        val currentList = listsWithIds.find { it.first == currentListId }?.second
        val listName = currentList?.name ?: "Lista actual"

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_observations, null)
        val observationsEditText = dialogView.findViewById<EditText>(R.id.observations_edit_text)
        val observationsTitle = dialogView.findViewById<TextView>(R.id.observations_title)

        observationsEditText.setText(currentObservations)
        observationsEditText.isEnabled = false
        observationsTitle.text = "Observaciones - $listName"

        // PREVENIR que el teclado se muestre automáticamente
        observationsEditText.showSoftInputOnFocus = false

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Observaciones de la Lista")
            .setView(dialogView)
            .setPositiveButton("Cerrar", null)
            .setNeutralButton("Editar") { _, _ ->
                showEditableObservationsDialog(currentListId, currentObservations, listName)
            }

        if (currentObservations.isNotEmpty()) {
            dialog.setNegativeButton("Limpiar") { _, _ ->
                saveListObservations(currentListId, "")
                showMessage("Observaciones eliminadas")
            }
        }

        val alertDialog = dialog.create()

        // Configurar la ventana para evitar que se muestre el teclado
        alertDialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        alertDialog.show()

        // Asegurarse de que el teclado esté oculto
        hideKeyboard(observationsEditText)
    }

    // Diálogo para editar observaciones (modo edición) - CORREGIDO
    private fun showEditableObservationsDialog(listId: String, currentObservations: String, listName: String) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_observations, null)
        val observationsEditText = dialogView.findViewById<EditText>(R.id.observations_edit_text)
        val observationsTitle = dialogView.findViewById<TextView>(R.id.observations_title)

        observationsEditText.setText(currentObservations)
        observationsEditText.isEnabled = true
        observationsTitle.text = "Editando Observaciones - $listName"

        // NO mostrar el teclado automáticamente
        observationsEditText.showSoftInputOnFocus = false

        val alertDialog = AlertDialog.Builder(requireContext())
            .setTitle("Editando Observaciones")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                val observations = observationsEditText.text.toString().trim()
                saveListObservations(listId, observations)
                showMessage("Observaciones guardadas")
                hideKeyboard(observationsEditText)
            }
            .setNegativeButton("Cancelar") { _, _ ->
                hideKeyboard(observationsEditText)
            }
            .setNeutralButton("Limpiar") { _, _ ->
                saveListObservations(listId, "")
                showMessage("Observaciones eliminadas")
                hideKeyboard(observationsEditText)
            }
            .create()

        // Configurar la ventana para controlar el teclado
        alertDialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        alertDialog.show()

        // Mostrar el teclado solo cuando el usuario toque el EditText
        observationsEditText.setOnClickListener {
            observationsEditText.postDelayed({
                observationsEditText.requestFocus()
                val inputMethodManager = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                inputMethodManager.showSoftInput(observationsEditText, InputMethodManager.SHOW_IMPLICIT)
            }, 100)
        }

        // También mostrar teclado al recibir foco (por si se navega con teclado)
        observationsEditText.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                observationsEditText.postDelayed({
                    val inputMethodManager = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    inputMethodManager.showSoftInput(observationsEditText, InputMethodManager.SHOW_IMPLICIT)
                }, 200)
            }
        }
    }

    // Guardar observaciones en Firestore
    private fun saveListObservations(listId: String, observations: String) {
        db.collection("listObservations").document(listId)
            .set(mapOf(
                "observations" to observations,
                "updatedAt" to FieldValue.serverTimestamp(),
                "updatedBy" to (auth.currentUser?.email ?: "")
            ))
            .addOnSuccessListener {
                listObservations[listId] = observations
                updateListInfoDisplay()
            }
            .addOnFailureListener { e ->
                showError("Error al guardar observaciones: ${e.message}")
            }
    }

    // Cargar observaciones de la lista actual
    private fun loadListObservations(listId: String) {
        db.collection("listObservations").document(listId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val observations = document.getString("observations") ?: ""
                    listObservations[listId] = observations
                } else {
                    listObservations[listId] = ""
                }
            }
            .addOnFailureListener { e ->
                listObservations[listId] = ""
            }
    }

    // Configurar listener para observaciones en tiempo real
    private fun setupListObservationsListener(listId: String) {
        listInfoListener?.remove()

        listInfoListener = db.collection("listObservations").document(listId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    return@addSnapshotListener
                }

                if (snapshot != null && snapshot.exists()) {
                    val observations = snapshot.getString("observations") ?: ""
                    listObservations[listId] = observations
                } else {
                    listObservations[listId] = ""
                }
            }
    }

    // Diálogo de opciones para división de gastos
    private fun showSplitOptionsDialog() {
        val currentListId = currentListId ?: run {
            showError("Selecciona una lista primero")
            return
        }

        val currentList = listsWithIds.find { it.first == currentListId }?.second
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        val isCreator = currentList?.let { list ->
            list.userId == userId || list.ownerEmail == currentUserEmail
        } ?: false

        val options = if (isCreator) {
            arrayOf("Gestionar Pagos", "Ver Estado Completo", "División Simple")
        } else {
            arrayOf("Ver Mi Pago")
        }

        AlertDialog.Builder(requireContext())
            .setTitle(if (isCreator) "Opciones de Gastos" else "Opciones de Gastos")
            .setItems(options) { _, which ->
                when {
                    isCreator && which == 0 -> showSimpleSplitDialog() // Gestión completa de pagos
                    isCreator && which == 1 -> showQuickPaymentStatus() // Ver estado completo
                    isCreator && which == 2 -> showBasicSplitDialog() // División simple
                    !isCreator && which == 0 -> showQuickPaymentStatus() // Ver mi pago
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // Mantén tu método original para división simple
    private fun showBasicSplitDialog() {
        val currentListId = currentListId ?: run {
            showError("Selecciona una lista primero")
            return
        }

        val currentList = listsWithIds.find { it.first == currentListId }?.second
        val participants = mutableListOf(auth.currentUser?.email ?: "")
        currentList?.sharedWith?.forEach { participants.add(it) }

        val purchaseInfo = currentList?.purchaseInfo
        val totalPrice = purchaseInfo?.get("totalPrice") as? Double

        if (totalPrice == null || totalPrice == 0.0) {
            showError("Primero establece el precio total de la compra usando 'Finalizar Compra'")
            return
        }

        calculateSimpleSplit(totalPrice, participants)
    }

    // Diálogo para finalizar compra y establecer precio total
    private fun showSimpleFinalizeDialog() {
        val currentListId = currentListId ?: run {
            showError("Selecciona una lista primero")
            return
        }

        val currentList = listsWithIds.find { it.first == currentListId }?.second
        val currentPurchaseInfo = currentList?.purchaseInfo
        val currentTotalPrice = currentPurchaseInfo?.get("totalPrice") as? Double

        val editText = EditText(requireContext()).apply {
            hint = "Precio total (ej: 45.50)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            currentTotalPrice?.let { setText(it.toString()) }
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Finalizar Compra")
            .setMessage("Introduce el precio total de la compra:")
            .setView(editText)
            .setPositiveButton("Guardar") { _, _ ->
                val priceText = editText.text.toString().trim()
                hideKeyboard(editText)
                if (priceText.isNotEmpty()) {
                    try {
                        val totalPrice = priceText.toDouble()
                        saveSimplePurchaseInfo(currentListId, totalPrice)
                        showMessage("Precio guardado: $totalPrice €")
                    } catch (e: NumberFormatException) {
                        showError("Precio debe ser un número válido")
                    }
                } else {
                    saveSimplePurchaseInfo(currentListId, null)
                    showMessage("Precio eliminado")
                }
            }
            .setNegativeButton("Cancelar") { _, _ ->
                hideKeyboard(editText)
            }
            .setOnDismissListener {
                hideKeyboard(editText)
            }
            .show()
    }

    // Guardar información de compra en Firestore
    private fun saveSimplePurchaseInfo(listId: String, totalPrice: Double?) {
        if (totalPrice != null) {
            val purchaseInfo = hashMapOf<String, Any>(
                "totalPrice" to totalPrice,
                "finalizedAt" to com.google.firebase.Timestamp.now(),
                "finalizedBy" to (auth.currentUser?.email ?: "")
            )

            db.collection("lists").document(listId)
                .update("purchaseInfo", purchaseInfo)
                .addOnSuccessListener {
                    updateListInfoDisplay()
                }
        } else {
            db.collection("lists").document(listId)
                .update("purchaseInfo", FieldValue.delete())
                .addOnSuccessListener {
                    updateListInfoDisplay()
                }
        }
    }

    // Diálogo para división de gastos
    private fun showSimpleSplitDialog() {
        val currentListId = currentListId ?: run {
            showError("Selecciona una lista primero")
            return
        }

        val currentList = listsWithIds.find { it.first == currentListId }?.second
        val purchaseInfo = currentList?.purchaseInfo
        val totalPrice = purchaseInfo?.get("totalPrice") as? Double

        if (totalPrice == null || totalPrice == 0.0) {
            showError("Primero establece el precio total de la compra usando 'Finalizar Compra'")
            return
        }

        // VERIFICAR SI EL USUARIO ES PROPIETARIO
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""
        val isCreator = currentList?.let { list ->
            list.userId == userId || list.ownerEmail == currentUserEmail
        } ?: false

        if (isCreator) {
            // PROPIETARIO: Cargar información completa de pagos
            loadPaymentInfo(currentListId, totalPrice)
        } else {
            // NO PROPIETARIO: Mostrar solo información personal
            showUserPaymentInfo(currentListId, totalPrice)
        }
    }

    // MOSTRAR INFORMACIÓN PERSONAL PARA USUARIOS NO PROPIETARIOS
    private fun showUserPaymentInfo(listId: String, totalAmount: Double) {
        db.collection("listPayments").document(listId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val paymentData = document.data
                    val participants = paymentData?.get("paymentParticipants") as? List<Map<String, Any>> ?: emptyList()
                    val payments = paymentData?.get("payments") as? Map<String, Map<String, Any>> ?: emptyMap()

                    val currentUserEmail = auth.currentUser?.email ?: ""
                    val sharePerPerson = if (participants.isNotEmpty()) totalAmount / participants.size else 0.0
                    val userPayment = payments[currentUserEmail]?.get("paid") as? Boolean ?: false

                    showUserPaymentSummary(totalAmount, participants.size, sharePerPerson, userPayment)
                } else {
                    // Si no hay datos de pagos, mostrar información básica
                    showUserPaymentSummary(totalAmount, 1, totalAmount, false)
                }
            }
            .addOnFailureListener {
                // En caso de error, mostrar información básica
                showUserPaymentSummary(totalAmount, 1, totalAmount, false)
            }
    }

    // MOSTRAR RESUMEN PERSONAL PARA USUARIOS NO PROPIETARIOS
    private fun showUserPaymentSummary(totalAmount: Double, participantsCount: Int, sharePerPerson: Double, isPaid: Boolean) {
        val summary = StringBuilder()

        // CORRECCIÓN: Mostrar información del precio solo si totalAmount > 0
        if (totalAmount > 0) {
            summary.append("Total gastado: ${"%.2f".format(totalAmount)} €\n")
            summary.append("Mi parte: ${"%.2f".format(sharePerPerson)} €\n\n")
        } else {
            summary.append("Total gastado: No establecido\n")
            summary.append("Mi parte: No calculada\n\n")
        }

        summary.append("MI ESTADO:\n")
        summary.append(if (isPaid) "PAGADO" else "PENDIENTE DE PAGO")
        summary.append("\n\n")

        if (totalAmount == 0.0) {
            summary.append("💡 El propietario debe establecer el precio total primero")
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Mi Pago")
            .setMessage(summary.toString())
            .setPositiveButton("Entendido", null)
            .show()
    }

    // Cargar información de pagos desde Firestore
    private fun loadPaymentInfo(listId: String, totalAmount: Double) {
        db.collection("listPayments").document(listId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val paymentData = document.data
                    showAdvancedSplitDialog(listId, totalAmount, paymentData)
                } else {
                    // Crear estructura inicial de pagos
                    showAdvancedSplitDialog(listId, totalAmount, null)
                }
            }
            .addOnFailureListener {
                showAdvancedSplitDialog(listId, totalAmount, null)
            }
    }

    // Diálogo avanzado de división de gastos - VERSIÓN CORREGIDA
    private fun showAdvancedSplitDialog(listId: String, totalAmount: Double, paymentData: Map<String, Any>?) {
        val currentList = listsWithIds.find { it.first == listId }?.second
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        // VERIFICAR SI EL USUARIO ACTUAL ES EL CREADOR
        val isCreator = currentList?.let { list ->
            list.userId == userId || list.ownerEmail == currentUserEmail
        } ?: false

        if (!isCreator) {
            showError("Solo el propietario de la lista puede gestionar los pagos")
            return
        }

        // Obtener participantes DESDE listPayments si existen, sino usar la estructura actual
        val participants = mutableListOf<Participant>()

        // Si hay datos de pagos existentes, usar esos participantes
        val existingParticipants = paymentData?.get("paymentParticipants") as? List<Map<String, Any>>

        if (existingParticipants != null && existingParticipants.isNotEmpty()) {
            // Usar los participantes de listPayments
            existingParticipants.forEach { participantData ->
                participants.add(Participant(
                    email = participantData["email"] as String,
                    name = participantData["name"] as String,
                    userId = participantData["userId"] as String?,
                    isOwner = participantData["isOwner"] as Boolean
                ))
            }
        } else {
            // Usar la estructura anterior como fallback
            participants.add(Participant(
                email = currentUserEmail,
                name = currentUserEmail.split("@")[0],
                userId = userId,
                isOwner = true
            ))

            // Añadir usuarios compartidos
            currentList?.sharedWith?.forEach { email ->
                participants.add(Participant(
                    email = email,
                    name = email.split("@")[0],
                    userId = null,
                    isOwner = false
                ))
            }
        }

        val existingPayments = paymentData?.get("payments") as? Map<String, Map<String, Any>>

        // Extraer solo el estado 'paid' de cada pago
        val paymentStatusMap = mutableMapOf<String, Boolean>()
        existingPayments?.forEach { (email, paymentInfo) ->
            val paid = paymentInfo["paid"] as? Boolean ?: false
            paymentStatusMap[email] = paid
        }

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_split_expenses, null)
        val recyclerView = dialogView.findViewById<RecyclerView>(R.id.participants_recycler_view)
        val totalAmountText = dialogView.findViewById<TextView>(R.id.total_amount_text)
        val sharePerPersonText = dialogView.findViewById<TextView>(R.id.share_per_person_text)
        val titleText = dialogView.findViewById<TextView>(R.id.dialog_title)
        val addParticipantButton = dialogView.findViewById<Button>(R.id.add_participant_button)

        titleText.text = "Gestión de Pagos"

        totalAmountText.text = "Total: ${"%.2f".format(totalAmount)} €"
        val initialSharePerPerson = if (participants.isNotEmpty()) totalAmount / participants.size else 0.0
        sharePerPersonText.text = "Por persona: ${"%.2f".format(initialSharePerPerson)} €"

        // Declarar adapter como lateinit y luego inicializarlo
        lateinit var adapter: PaymentParticipantsAdapter

        // Usar una referencia a la función en lugar de capturar la variable directamente
        val removeParticipantCallback: (Participant) -> Unit = { participant ->
            showRemoveParticipantConfirmation(participant, adapter, listId, totalAmount, dialogView)
        }

        // Usar paymentStatusMap en lugar de existingPayments
        adapter = PaymentParticipantsAdapter(
            participants,
            paymentStatusMap,
            onRemoveParticipant = removeParticipantCallback
        )

        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Configurar botón para añadir participantes
        addParticipantButton.setOnClickListener {
            showAddParticipantDialog(adapter, listId, totalAmount, dialogView)
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Gestión Completa de Pagos")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                savePaymentInfo(listId, currentList?.name ?: "Lista sin nombre",
                    adapter.getCurrentParticipants(), adapter.getPaymentsStatus(), totalAmount)
            }
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Ver Resumen") { _, _ ->
                showPaymentSummary(listId, totalAmount, adapter.getCurrentParticipants(), adapter.getPaymentsStatus(), true)
            }
            .create()

        dialog.show()
    }

    // Diálogo de confirmación para eliminar participante
    private fun showRemoveParticipantConfirmation(
        participant: Participant,
        adapter: PaymentParticipantsAdapter,
        listId: String,
        totalAmount: Double,
        dialogView: View
    ) {
        AlertDialog.Builder(requireContext())
            .setTitle("Eliminar de la división")
            .setMessage("¿Eliminar a ${participant.name} (${participant.email}) de la división de gastos?\n\nEsta acción no afecta a la lista compartida, solo lo elimina de la división de pagos.")
            .setPositiveButton("Eliminar") { _, _ ->
                adapter.removeParticipant(participant)
                showMessage("${participant.name} eliminado de la división de gastos")

                // Recalcular y actualizar el precio por persona
                val currentParticipants = adapter.getCurrentParticipants()
                val newSharePerPerson = if (currentParticipants.isNotEmpty()) totalAmount / currentParticipants.size else 0.0
                updateSharePerPersonText(newSharePerPerson, dialogView)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun updateSharePerPersonText(sharePerPerson: Double, dialogView: View) {
        try {
            val sharePerPersonText = dialogView.findViewById<TextView>(R.id.share_per_person_text)
            sharePerPersonText.text = "Por persona: ${"%.2f".format(sharePerPerson)} €"
        } catch (e: Exception) {
            // Ignorar errores si la vista no está disponible
        }
    }

    // Diálogo para añadir participante - ACTUALIZADO
    private fun showAddParticipantDialog(
        adapter: PaymentParticipantsAdapter,
        listId: String,
        totalAmount: Double,
        dialogView: View
    ) {
        val editText = EditText(requireContext()).apply {
            hint = "Email del participante"
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Añadir participante")
            .setMessage("Introduce el email del usuario para añadirlo a la división de gastos:")
            .setView(editText)
            .setPositiveButton("Añadir") { _, _ ->
                val email = editText.text.toString().trim()
                if (email.isNotEmpty() && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    addParticipantToSplit(email, adapter, listId, totalAmount, dialogView)
                } else {
                    showError("Introduce un email válido")
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // Añadir participante a la división - ACTUALIZADO
    private fun addParticipantToSplit(
        email: String,
        adapter: PaymentParticipantsAdapter,
        listId: String,
        totalAmount: Double,
        dialogView: View
    ) {
        val currentList = listsWithIds.find { it.first == listId }?.second
        val currentParticipants = adapter.getCurrentParticipants()

        // Verificar si ya existe
        if (currentParticipants.any { it.email.equals(email, ignoreCase = true) }) {
            showError("Este usuario ya está en la división de gastos")
            return
        }

        // Verificar si el email es del propietario
        val currentUserEmail = auth.currentUser?.email ?: ""
        if (email.equals(currentUserEmail, ignoreCase = true)) {
            showError("No puedes añadirte a ti mismo (ya estás incluido como propietario)")
            return
        }

        // Verificar si el email está en la lista compartida
        val isInSharedList = currentList?.sharedWith?.any { it.equals(email, ignoreCase = true) } == true
        if (!isInSharedList) {
            showError("Este usuario no tiene acceso a la lista. Primero comparte la lista con él.")
            return
        }

        // Crear nuevo participante
        val newParticipant = Participant(
            email = email,
            name = email.split("@")[0],
            userId = null,
            isOwner = false
        )

        // Actualizar el adaptador
        val updatedParticipants = currentParticipants.toMutableList().apply {
            add(newParticipant)
        }

        adapter.updateParticipants(updatedParticipants)
        showMessage("$email añadido a la división de gastos")

        // Recalcular y actualizar el precio por persona
        val newSharePerPerson = if (updatedParticipants.isNotEmpty()) totalAmount / updatedParticipants.size else 0.0
        updateSharePerPersonText(newSharePerPerson, dialogView)
    }

    // Guardar información de pagos en Firestore
    private fun savePaymentInfo(
        listId: String,
        listName: String,
        participants: List<Participant>,
        paymentsStatus: Map<String, Boolean>,
        totalAmount: Double
    ) {
        try {
            // Convertir participantes a formato Firestore
            val paymentParticipantsList = mutableListOf<Map<String, Any?>>()
            participants.forEach { participant ->
                paymentParticipantsList.add(
                    mapOf(
                        "email" to participant.email,
                        "name" to participant.name,
                        "userId" to participant.userId,
                        "isOwner" to participant.isOwner
                    )
                )
            }

            // Convertir pagos a formato Firestore correctamente
            val paymentsMap = mutableMapOf<String, Map<String, Any?>>()
            val currentUserEmail = auth.currentUser?.email ?: ""
            val now = com.google.firebase.Timestamp.now()

            // Asegurarse de que TODOS los participantes estén en paymentsMap
            participants.forEach { participant ->
                val currentStatus = paymentsStatus[participant.email] ?: false
                paymentsMap[participant.email] = mapOf(
                    "paid" to currentStatus,
                    "paidAt" to if (currentStatus) now else null,
                    "paidBy" to if (currentStatus) currentUserEmail else null,
                    "updatedAt" to now
                )
            }

            // Crear documento completo
            val paymentData = mapOf(
                "listId" to listId,
                "listName" to listName,
                "paymentParticipants" to paymentParticipantsList,
                "payments" to paymentsMap,
                "totalAmount" to totalAmount,
                "updatedAt" to now,
                "updatedBy" to currentUserEmail
            )

            // Guardar en Firestore
            db.collection("listPayments").document(listId)
                .set(paymentData)
                .addOnSuccessListener {
                    showMessage("Información de pagos guardada correctamente")
                }
                .addOnFailureListener { e ->
                    showError("Error al guardar pagos: ${e.message}")
                }

        } catch (e: Exception) {
            showError("Error al procesar datos de pagos: ${e.message}")
        }
    }

    private fun setupPaymentListener(listId: String) {
        db.collection("listPayments").document(listId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
            }
    }

    private fun showQuickPaymentStatus() {
        val currentListId = currentListId ?: run {
            showError("Selecciona una lista primero")
            return
        }

        val currentList = listsWithIds.find { it.first == currentListId }?.second
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""
        val isCreator = currentList?.let { list ->
            list.userId == userId || list.ownerEmail == currentUserEmail
        } ?: false

        // PRIMERO: Obtener el precio total desde purchaseInfo de la lista
        val purchaseInfoTotal = currentList?.purchaseInfo?.get("totalPrice") as? Double ?: 0.0

        db.collection("listPayments").document(currentListId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val paymentData = document.data
                    // Usar el totalAmount de listPayments si existe, sino usar purchaseInfoTotal
                    val totalAmount = paymentData?.get("totalAmount") as? Double ?: purchaseInfoTotal
                    val participants = paymentData?.get("paymentParticipants") as? List<Map<String, Any>> ?: emptyList()
                    val payments = paymentData?.get("payments") as? Map<String, Map<String, Any>> ?: emptyMap()

                    // Extraer solo el estado 'paid'
                    val paymentsStatus = mutableMapOf<String, Boolean>()
                    payments.forEach { (email, paymentInfo) ->
                        val paid = paymentInfo["paid"] as? Boolean ?: false
                        paymentsStatus[email] = paid
                    }

                    val participantList = participants.map {
                        Participant(
                            it["email"] as String,
                            it["name"] as String,
                            it["userId"] as String?,
                            it["isOwner"] as Boolean
                        )
                    }

                    if (isCreator) {
                        showPaymentSummary(currentListId, totalAmount, participantList, paymentsStatus, true)
                    } else {
                        // Para no propietarios, mostrar solo su información
                        val sharePerPerson = if (participantList.isNotEmpty()) totalAmount / participantList.size else 0.0
                        val userPayment = paymentsStatus[currentUserEmail] ?: false
                        showUserPaymentSummary(totalAmount, participantList.size, sharePerPerson, userPayment)
                    }
                } else {
                    // Si no existe listPayments, usar purchaseInfoTotal
                    val participants = mutableListOf<Participant>()
                    participants.add(Participant(
                        email = currentUserEmail,
                        name = currentUserEmail.split("@")[0],
                        userId = userId,
                        isOwner = true
                    ))

                    currentList?.sharedWith?.forEach { email ->
                        participants.add(Participant(
                            email = email,
                            name = email.split("@")[0],
                            userId = null,
                            isOwner = false
                        ))
                    }

                    if (isCreator) {
                        showPaymentSummary(currentListId, purchaseInfoTotal, participants, emptyMap(), true)
                    } else {
                        val sharePerPerson = if (participants.isNotEmpty()) purchaseInfoTotal / participants.size else 0.0
                        showUserPaymentSummary(purchaseInfoTotal, participants.size, sharePerPerson, false)
                    }
                }
            }
            .addOnFailureListener {
                // En caso de error, usar purchaseInfoTotal
                val participants = mutableListOf<Participant>()
                participants.add(Participant(
                    email = currentUserEmail,
                    name = currentUserEmail.split("@")[0],
                    userId = userId,
                    isOwner = true
                ))

                currentList?.sharedWith?.forEach { email ->
                    participants.add(Participant(
                        email = email,
                        name = email.split("@")[0],
                        userId = null,
                        isOwner = false
                    ))
                }

                if (isCreator) {
                    showPaymentSummary(currentListId, purchaseInfoTotal, participants, emptyMap(), true)
                } else {
                    val sharePerPerson = if (participants.isNotEmpty()) purchaseInfoTotal / participants.size else 0.0
                    showUserPaymentSummary(purchaseInfoTotal, participants.size, sharePerPerson, false)
                }
            }
    }

    // Mostrar resumen de pagos
    private fun showPaymentSummary(
        listId: String,
        totalAmount: Double,
        participants: List<Participant>,
        paymentsStatus: Map<String, Boolean>,
        isOwnerView: Boolean = false
    ) {
        val sharePerPerson = if (participants.isNotEmpty() && totalAmount > 0) totalAmount / participants.size else 0.0
        val paidCount = paymentsStatus.count { it.value }
        val pendingCount = participants.size - paidCount

        val summary = StringBuilder()

        // Mostrar información del precio solo si totalAmount > 0
        if (totalAmount > 0) {
            summary.append("Total gastado: ${"%.2f".format(totalAmount)} €\n")
            summary.append("Precio por persona: ${"%.2f".format(sharePerPerson)} €\n\n")
        } else {
            summary.append("Total gastado: No establecido\n")
            summary.append("Precio por persona: No calculado\n\n")
        }

        summary.append("ESTADO DE PAGOS:\n")
        summary.append("Pagados: $paidCount\n")
        summary.append("Pendientes: $pendingCount\n\n")

        if (isOwnerView) {
            summary.append("PARTICIPANTES:\n")
            participants.forEach { participant ->
                val paid = paymentsStatus[participant.email] == true
                val status = if (paid) "✅" else "❌"
                val ownerIndicator = if (participant.isOwner) "" else ""
                summary.append("• ${participant.name}$ownerIndicator: $status\n")
            }

            if (totalAmount == 0.0) {
                summary.append("\nPara gestionar pagos, establece primero el precio total en 'Finalizar Compra'")
            }
        } else {
            summary.append("Solo el propietario puede ver los detalles completos de los participantes.")
        }

        AlertDialog.Builder(requireContext())
            .setTitle(if (isOwnerView) "Estado Completo de Pagos" else "Estado de Pagos")
            .setMessage(summary.toString())
            .setPositiveButton("Entendido", null)
            .show()
    }

    // Data class para participantes
    data class Participant(
        val email: String,
        val name: String,
        val userId: String?,
        val isOwner: Boolean
    )

    // Calcular división de gastos entre participantes
    private fun calculateSimpleSplit(totalAmount: Double, participants: List<String>) {
        val sharePerPerson = totalAmount / participants.size
        val result = StringBuilder()

        result.append("Resumen de Gastos\n\n")
        result.append("Total gastado: ${"%.2f".format(totalAmount)} €\n")
        result.append("Número de personas: ${participants.size}\n")
        result.append("Precio por persona: ${"%.2f".format(sharePerPerson)} €\n\n")

        AlertDialog.Builder(requireContext())
            .setTitle("División de Gastos")
            .setMessage(result.toString())
            .setPositiveButton("Entendido", null)
            .show()
    }

    // Diálogo para información adicional de la lista
    private fun showSimpleExtraInfoDialog() {
        val currentListId = currentListId ?: run {
            showError("Selecciona una lista primero")
            return
        }

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_extra_info, null)
        val extraInfoEditText = dialogView.findViewById<EditText>(R.id.extra_info_edit_text)

        // PREVENIR que el teclado se muestre automáticamente
        extraInfoEditText.showSoftInputOnFocus = false

        val alertDialog = AlertDialog.Builder(requireContext())
            .setTitle("Información Adicional")
            .setMessage("Añade información general sobre la compra:")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                val extraInfo = extraInfoEditText.text.toString().trim()
                hideKeyboard(extraInfoEditText)
                saveSimpleExtraInfo(currentListId, extraInfo)
                showMessage("Información guardada")
            }
            .setNegativeButton("Cancelar") { _, _ ->
                hideKeyboard(extraInfoEditText)
            }
            .create()

        // Configurar la ventana para evitar que se muestre el teclado
        alertDialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        alertDialog.show()

        // Mostrar el teclado solo cuando el usuario toque el EditText
        extraInfoEditText.setOnClickListener {
            extraInfoEditText.postDelayed({
                extraInfoEditText.requestFocus()
                val inputMethodManager = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                inputMethodManager.showSoftInput(extraInfoEditText, InputMethodManager.SHOW_IMPLICIT)
            }, 100)
        }
    }

    // Guardar información adicional en Firestore
    private fun saveSimpleExtraInfo(listId: String, extraInfo: String) {
        db.collection("lists").document(listId)
            .update("extraInfo", extraInfo)
            .addOnSuccessListener {
                updateListInfoDisplay()
            }
    }

    // Configurar adaptador para items de compra
    private fun setupAdapters() {
        itemsAdapter = ShoppingItemsAdapter(
            requireContext(),
            emptyList(),
            onItemChecked = { item, isChecked ->
                updateItemInFirestore(item, isChecked, true)
            },
            onDeleteClick = { item ->
                showDeleteConfirmation(item)
            }
        )
        binding.itemsRecyclerView.adapter = itemsAdapter
        binding.itemsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
    }

    // Actualizar item en Firestore (marcar como comprado/desmarcar)
    private fun updateItemInFirestore(item: ShoppingItem, isChecked: Boolean, isUserAction: Boolean = false) {
        val updates = hashMapOf<String, Any>(
            "completed" to isChecked,
            "category" to (if (isChecked) ProductCategory.COMPRADO else determineCategory(item.text))
        )

        // Guardar información del comprador si se marca como comprado
        if (isChecked && isUserAction) {
            updates["purchasedBy"] = auth.currentUser?.email ?: ""
            updates["purchasedAt"] = com.google.firebase.Timestamp.now()
        }

        // Limpiar información de compra si se desmarca
        if (!isChecked && isUserAction) {
            updates["purchasedBy"] = ""
            updates["purchasedAt"] = FieldValue.delete()
        }

        db.collection("items")
            .whereEqualTo("text", item.text)
            .whereEqualTo("listId", item.listId)
            .whereEqualTo("createdAt", item.createdAt)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val doc = querySnapshot.documents[0]
                    doc.reference.update(updates)
                }
            }
    }

    // Añadir nuevo item a la lista
    private fun addItem(text: String) {
        val listId = currentListId ?: run {
            showError("No hay lista seleccionada")
            return
        }

        val userId = Firebase.auth.currentUser?.uid ?: run {
            showError("Usuario no autenticado")
            return
        }
        val userEmail = Firebase.auth.currentUser?.email ?: ""

        val category = determineCategory(text)

        // Verificar si el producto ya existe en la lista
        db.collection("items")
            .whereEqualTo("text", text)
            .whereEqualTo("listId", listId)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    showError("'$text' ya está en la lista")
                    return@addOnSuccessListener
                }

                // Crear nuevo item
                val item = hashMapOf(
                    "text" to text,
                    "completed" to false,
                    "listId" to listId,
                    "userId" to userId,
                    "addedBy" to userEmail,
                    "createdAt" to com.google.firebase.Timestamp.now(),
                    "category" to category.name,
                    "purchasedBy" to "",
                    "purchasedAt" to null
                )

                db.collection("items").add(item)
            }
            .addOnFailureListener { e ->
                showError("Error al verificar producto: ${e.message}")
            }
    }

    // Interfaz para API de productos
    interface ProductApiService {
        @GET("product/{barcode}.json")
        suspend fun getProductByBarcode(@Path("barcode") barcode: String): ProductResponse
    }

    data class ProductResponse(
        val product: Product?
    )

    data class Product(
        val product_name: String?,
        val brands: String?,
        val categories: String?
    )

    // Iniciar escaneo de código de barras
    private fun startBarcodeScan() {
        try {
            if (!isAdded || activity == null || activity?.isFinishing == true) {
                showError("No se puede iniciar el escáner en este momento")
                return
            }

            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(arrayOf(Manifest.permission.CAMERA),
                    CAMERA_PERMISSION_REQUEST_CODE)
                return
            }

            IntentIntegrator.forSupportFragment(this)
                .setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES)
                .setPrompt("Escanea un código de barras")
                .setCameraId(0)
                .setBeepEnabled(true)
                .setBarcodeImageEnabled(false)
                .setOrientationLocked(true)
                .setCaptureActivity(PortraitCaptureActivity::class.java)
                .initiateScan()

        } catch (e: Exception) {
            showError("Error al iniciar cámara: ${e.localizedMessage}")
        }
    }

    // Actualizar colores del selector de tipo de lista
    private fun updateSelectorChipColors() {
        if (!isAdded || context == null) return

        binding.listTypeSelectorChipGroup.children.forEach { view ->
            if (view is Chip) {
                when (view.text) {
                    "Listas" -> {
                        val isSelected = selectedListType == ListType.MY_LISTS
                        view.setChipBackgroundColorResource(
                            if (isSelected) R.color.selected_my_list_color
                            else R.color.chip_background_color
                        )
                        view.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                if (isSelected) R.color.selected_list_text_color
                                else R.color.dark_blue
                            )
                        )
                    }
                    "Compartidas" -> {
                        val isSelected = selectedListType == ListType.SHARED_LISTS
                        view.setChipBackgroundColorResource(
                            if (isSelected) R.color.selected_shared_list_color
                            else R.color.chip_background_color
                        )
                        view.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                if (isSelected) R.color.selected_list_text_color
                                else R.color.dark_blue
                            )
                        )
                    }
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            CAMERA_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startBarcodeScan()
                } else {
                    showError("Se necesitan permisos de cámara para escanear")
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (!isAdded) return

        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                showMessage("Escaneo cancelado")
            } else {
                handleBarcode(result.contents)
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    // Procesar código de barras escaneado
    private fun handleBarcode(barcode: String) {
        if (currentListId == null || listsWithIds.none { it.first == currentListId }) {
            showError("Selecciona una lista válida primero")
            if (listsWithIds.isNotEmpty()) {
                val firstListId = listsWithIds.first().first
                currentListId = firstListId
                updateListSelectionInUI(firstListId)
                showMessage("Lista '${listsWithIds.first().second.name}' seleccionada")
            } else {
                showError("No hay listas disponibles. Crea una lista primero.")
                return
            }
        }

        showMessage("Buscando producto...")
        val originalListId = currentListId

        CoroutineScope(Dispatchers.IO + exceptionHandler).launch {
            try {
                val response = productApi.getProductByBarcode(barcode)

                withContext(Dispatchers.Main) {
                    if (response.product?.product_name != null) {
                        val product = response.product

                        val formattedName = formatProductName(
                            product.product_name,
                            product.brands,
                            product.categories
                        )

                        currentListId = originalListId
                        addItem(formattedName)

                    } else {
                        showMessage("Producto no encontrado")
                        Handler(Looper.getMainLooper()).postDelayed({
                            showProductNameDialog(barcode)
                        }, 1000)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {

                    val errorMessage = when {
                        e is SocketTimeoutException -> "⏰ Tiempo de espera agotado. Revisa tu conexión."
                        e is IOException || e is UnknownHostException -> "📡 Error de conexión. Verifica tu internet."
                        e is HttpException -> "🔧 Error del servidor: ${e.code()}"
                        else -> "Error al buscar producto: ${e.localizedMessage}"
                    }

                    showError(errorMessage)
                    currentListId = originalListId

                    Handler(Looper.getMainLooper()).postDelayed({
                        showProductNameDialog(barcode)
                    }, 1500)
                }
            }
        }
    }

    // Seleccionar lista en la interfaz
    private fun selectListInUI(listId: String) {
        var found = false

        binding.listsChipGroup.children.forEach { view ->
            if (view is Chip && view.tag == listId) {
                view.isChecked = true
                found = true
            }
        }
    }

    // Añadir selector de tipo de lista
    private fun addListTypeSelector() {
        if (!isAdded || context == null) return

        val selectorChipGroup = binding.listTypeSelectorChipGroup

        val myListsChip = Chip(requireContext()).apply {
            text = "Listas"
            isCheckable = true
            isChecked = selectedListType == ListType.MY_LISTS
            setChipBackgroundColorResource(
                if (selectedListType == ListType.MY_LISTS) R.color.selected_my_list_color
                else R.color.chip_background_color
            )
            setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    if (selectedListType == ListType.MY_LISTS) R.color.selected_list_text_color
                    else R.color.dark_blue
                )
            )
            chipStrokeWidth = 0f

            setOnClickListener {
                if (selectedListType != ListType.MY_LISTS) {
                    selectedListType = ListType.MY_LISTS
                    updateSelectorChipColors()
                    updateListsDisplay()
                    updateShareButtonVisibility()
                }
            }
        }

        val sharedListsChip = Chip(requireContext()).apply {
            text = "Compartidas"
            isCheckable = true
            isChecked = selectedListType == ListType.SHARED_LISTS
            setChipBackgroundColorResource(
                if (selectedListType == ListType.SHARED_LISTS) R.color.selected_shared_list_color
                else R.color.chip_background_color
            )
            setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    if (selectedListType == ListType.SHARED_LISTS) R.color.selected_list_text_color
                    else R.color.dark_blue
                )
            )
            chipStrokeWidth = 0f

            setOnClickListener {
                if (selectedListType != ListType.SHARED_LISTS) {
                    selectedListType = ListType.SHARED_LISTS
                    updateSelectorChipColors()
                    updateListsDisplay()
                    updateShareButtonVisibility()
                }
            }
        }

        selectorChipGroup.addView(myListsChip)
        selectorChipGroup.addView(sharedListsChip)
    }

    // Mostrar listas según el tipo seleccionado
    private fun showListsBySelectedType(
        ownedLists: List<Pair<String, ShoppingList>>,
        sharedWithMeLists: List<Pair<String, ShoppingList>>,
        previousSelectedListId: String?
    ): String? {
        val listsToShow = when (selectedListType) {
            ListType.MY_LISTS -> ownedLists
            ListType.SHARED_LISTS -> sharedWithMeLists
        }

        var newSelectedListId: String? = null
        var hasSelectedList = false

        if (listsToShow.isNotEmpty()) {
            listsToShow.forEachIndexed { index, pair ->
                val listName = when (selectedListType) {
                    ListType.MY_LISTS -> {
                        val isAlsoShared = pair.second.sharedWith.isNotEmpty()
                        if (isAlsoShared) "${pair.second.name} (compartida)" else pair.second.name
                    }
                    ListType.SHARED_LISTS -> {
                        val ownerName = if (pair.second.ownerEmail.isNotEmpty()) {
                            " (${pair.second.ownerEmail.split("@")[0]})"
                        } else {
                            ""
                        }
                        "${pair.second.name}$ownerName"
                    }
                }

                createChip(
                    listName,
                    index,
                    pair.first,
                    selectedListType == ListType.SHARED_LISTS,
                    selectedListType == ListType.MY_LISTS
                )?.let { chip ->
                    binding.listsChipGroup.addView(chip)

                    val shouldSelectThisChip = pair.first == previousSelectedListId ||
                            (previousSelectedListId == null && index == 0)

                    if (shouldSelectThisChip) {
                        chip.isChecked = true
                        newSelectedListId = pair.first
                        hasSelectedList = true

                        updateChipColors(
                            chip,
                            selectedListType == ListType.MY_LISTS,
                            selectedListType == ListType.SHARED_LISTS,
                            true
                        )
                    }
                }
            }

            // Seleccionar primera lista si no hay selección
            if (!hasSelectedList && listsToShow.isNotEmpty()) {
                newSelectedListId = listsToShow.first().first
                val firstChip = binding.listsChipGroup.getChildAt(0) as? Chip
                firstChip?.isChecked = true

                firstChip?.let { chip ->
                    updateChipColors(
                        chip,
                        selectedListType == ListType.MY_LISTS,
                        selectedListType == ListType.SHARED_LISTS,
                        true
                    )
                }
            }
        } else {
            val noListsTextView = TextView(requireContext()).apply {
                text = when (selectedListType) {
                    ListType.MY_LISTS -> "No tienes listas propias"
                    ListType.SHARED_LISTS -> "No tienes listas compartidas"
                }
                setTextColor(ContextCompat.getColor(requireContext(), R.color.dark_gray))
                gravity = android.view.Gravity.CENTER
                setPadding(0, 32, 0, 32)
            }
            binding.listsChipGroup.addView(noListsTextView)
        }
        return newSelectedListId
    }

    // Actualizar display de listas
    private fun updateListsDisplay() {
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        val ownedLists = listsWithIds.filter { pair ->
            val list = pair.second
            list.userId == userId || list.ownerEmail == currentUserEmail
        }

        val sharedWithMeLists = listsWithIds.filter { pair ->
            val list = pair.second
            list.sharedWith.contains(currentUserEmail) &&
                    !(list.userId == userId || list.ownerEmail == currentUserEmail)
        }

        binding.listsChipGroup.removeAllViews()

        val newSelectedListId = showListsBySelectedType(ownedLists, sharedWithMeLists, currentListId)

        if (newSelectedListId != null) {
            currentListId = newSelectedListId
            loadItemsForList(newSelectedListId)

            loadListObservations(newSelectedListId)
            setupListObservationsListener(newSelectedListId)
        } else if (currentListId != null && !listsWithIds.any { it.first == currentListId }) {
            currentListId = null
            itemsAdapter.updateData(emptyList())
            listInfoListener?.remove()
        }

        // Actualizar visibilidad de TODOS los botones
        updateFABVisibility()
        updateSplitExpensesButtonVisibility()
        updateShareButtonVisibility()
        updateCreateListButtonVisibility()
        updateFinalizePurchaseButtonVisibility()
        updateExtraInfoButtonVisibility()
        updateScanBarcodeButtonVisibility()

        updateUIByListType()
        updateSelectorChipColors()
    }

    // Actualizar UI según tipo de lista
    private fun updateUIByListType() {
        val hasLists = when (selectedListType) {
            ListType.MY_LISTS -> listsWithIds.any { pair ->
                val list = pair.second
                val userId = auth.currentUser?.uid ?: ""
                val currentUserEmail = auth.currentUser?.email ?: ""
                list.userId == userId || list.ownerEmail == currentUserEmail
            }
            ListType.SHARED_LISTS -> listsWithIds.any { pair ->
                val list = pair.second
                val userId = auth.currentUser?.uid ?: ""
                val currentUserEmail = auth.currentUser?.email ?: ""
                list.sharedWith.contains(currentUserEmail) &&
                        !(list.userId == userId || list.ownerEmail == currentUserEmail)
            }
        }

        binding.itemsSectionLayout.visibility = if (hasLists && currentListId != null) View.VISIBLE else View.GONE

        if (hasLists && currentListId != null) {
            listInfoSection.visibility = View.VISIBLE
            updateListInfoDisplay()
        } else {
            listInfoSection.visibility = View.GONE
        }

        // Actualizar botones
        updateFABVisibility()
        updateShareButtonVisibility()
        updateCreateListButtonVisibility()
        updateSplitExpensesButtonVisibility()
    }

    // Añadir item a la lista seleccionada
    private fun addItemToSelectedList(itemText: String, category: ProductCategory) {
        if (!isAdded || activity == null) return

        val validListId = currentListId?.takeIf { listId ->
            listsWithIds.any { it.first == listId }
        } ?: run {
            if (listsWithIds.isNotEmpty()) {
                listsWithIds.first().first.also {
                    currentListId = it
                    binding.listsChipGroup.children.forEach { child ->
                        if (child is Chip && child.tag == it) {
                            child.isChecked = true
                        }
                    }
                }
            } else {
                showError("No hay listas disponibles")
                return
            }
        }

        addItem(itemText)
    }

    // Actualizar información de la lista mostrada
    private fun updateListInfoDisplay() {
        val currentList = listsWithIds.find { it.first == currentListId }?.second ?: run {
            listInfoSection.visibility = View.GONE
            return
        }

        priceInfoLayout.visibility = View.VISIBLE
        updatePriceInfo(currentList)

        listInfoSection.visibility = View.VISIBLE

        // Mostrar información de división de gastos si existe
        showSplitInfoIfAvailable(currentList)
    }

    // Mostrar información de división de gastos
    private fun showSplitInfoIfAvailable(list: ShoppingList) {
        val listId = currentListId ?: return
        val purchaseInfo = list.purchaseInfo
        val totalPrice = purchaseInfo?.get("totalPrice") as? Double

        if (totalPrice != null && totalPrice > 0) {
            // Cargar información de pagos para mostrar detalles
            db.collection("listPayments").document(listId)
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val paymentData = document.data
                        val participants = paymentData?.get("paymentParticipants") as? List<Map<String, Any>> ?: emptyList()

                        if (participants.isNotEmpty()) {
                            val sharePerPerson = totalPrice / participants.size

                            // CORRECCIÓN: Mostrar solo el precio total, sin información de división
                            val priceText = StringBuilder()
                            priceText.append("Total: ${"%.2f".format(totalPrice)} €")

                            // Eliminar las líneas que muestran participantes y precio por persona
                            // priceText.append("Participantes: ${participants.size}\n")  // ELIMINAR
                            // priceText.append("Cada uno: ${"%.2f".format(sharePerPerson)} €")  // ELIMINAR

                            priceInfoText.text = priceText.toString()
                        } else {
                            // Si no hay participantes, mostrar solo el precio total
                            priceInfoText.text = "Total: ${"%.2f".format(totalPrice)} €"
                        }
                    } else {
                        // Si no hay datos de pagos, mostrar solo el precio total
                        priceInfoText.text = "Total: ${"%.2f".format(totalPrice)} €"
                    }
                }
                .addOnFailureListener {
                    // En caso de error, mostrar solo el precio total
                    priceInfoText.text = "Total: ${"%.2f".format(totalPrice)} €"
                }
        }
    }

    // Actualizar información de precio
    private fun updatePriceInfo(list: ShoppingList) {
        val purchaseInfo = list.purchaseInfo
        val totalPrice = purchaseInfo?.get("totalPrice") as? Double

        val priceText = StringBuilder()

        if (totalPrice != null && totalPrice > 0) {
            val formattedPrice = "%.2f".format(totalPrice)
            priceText.append("Total: $formattedPrice €")

            // ELIMINAR la llamada a showBasicSplitInfo si no quieres mostrar información de división
            // showBasicSplitInfo(totalPrice, list)
        } else {
            priceText.append("Precio no establecido")
        }

        priceInfoText.text = priceText.toString()
    }

    // Mostrar información básica de división
    private fun showBasicSplitInfo(totalAmount: Double, list: ShoppingList) {
        val listId = currentListId ?: return

        db.collection("listPayments").document(listId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val paymentData = document.data
                    val participants = paymentData?.get("paymentParticipants") as? List<Map<String, Any>> ?: emptyList()

                    if (participants.isNotEmpty()) {
                        val sharePerPerson = totalAmount / participants.size

                        // Crear un TextView adicional para mostrar la información de división
                        val splitInfoText = TextView(requireContext()).apply {
                            text = "División: ${participants.size} personas - ${"%.2f".format(sharePerPerson)} € c/u"
                            setTextColor(ContextCompat.getColor(requireContext(), R.color.dark_gray))
                            textSize = 12f
                            setPadding(0, 8, 0, 0)
                        }

                        // Añadir al layout si no existe
                        if (priceInfoLayout.findViewById<TextView>(R.id.split_info_text) == null) {
                            splitInfoText.id = R.id.split_info_text
                            priceInfoLayout.addView(splitInfoText)
                        } else {
                            // Actualizar texto si ya existe
                            priceInfoLayout.findViewById<TextView>(R.id.split_info_text).text =
                                "División: ${participants.size} personas - ${"%.2f".format(sharePerPerson)} € c/u"
                        }
                    }
                }
            }
    }

    // Formatear nombre del producto
    private fun formatProductName(productName: String?, brand: String?, categories: String?): String {
        var name = productName?.trim() ?: "Producto desconocido"
        val brandName = brand?.split(",")?.firstOrNull()?.trim() ?: ""
        val category = categories?.split(",")?.firstOrNull()?.trim() ?: ""

        name = name.replace(Regex("\\s+"), " ").trim()

        val cleanBrand = if (brandName.isNotEmpty()) {
            brandName.replace(Regex("[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]"), "").trim()
        } else {
            ""
        }

        return if (cleanBrand.isNotEmpty() && !name.contains(cleanBrand, ignoreCase = true)) {
            "$name ($cleanBrand)"
        } else {
            name
        }
    }

    // Diálogo para ingresar nombre de producto manualmente
    private fun showProductNameDialog(barcode: String) {
        if (!isAdded || activity == null || activity?.isFinishing == true) return

        try {
            val editText = EditText(requireContext()).apply {
                hint = "Nombre del producto (ej: Galletas Lotus)"
                setPadding(32, 16, 32, 16)
            }

            AlertDialog.Builder(requireContext())
                .setTitle("📝 Producto no encontrado")
                .setMessage("Código: $barcode\n\nIntroduce el nombre manualmente:")
                .setView(editText)
                .setPositiveButton("Añadir") { _, _ ->
                    val productName = editText.text.toString().trim()
                    if (productName.isNotEmpty()) {
                        hideKeyboard(editText)
                        addItem(productName)
                        showMessage("Producto añadido: $productName")
                    } else {
                        showError("Debes introducir un nombre")
                    }
                }
                .setNegativeButton("Cancelar") { _, _ ->
                    hideKeyboard(editText)
                    showMessage("Producto no añadido")
                }
                .setOnDismissListener {
                    hideKeyboard(editText)
                }
                .show()

            editText.requestFocus()
            val inputMethodManager = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)

        } catch (e: Exception) {
            showError("Error al abrir el diálogo")
        }
    }

    // Crear chip para lista
    private fun createChip(
        text: String,
        index: Int,
        listId: String,
        isSharedWithMe: Boolean,
        isOwnedByMe: Boolean
    ): Chip? {
        return if (!isAdded || context == null) {
            null
        } else {
            Chip(requireContext()).apply {
                id = View.generateViewId()
                this.text = text
                tag = listId
                isCheckable = true
                isCloseIconVisible = isOwnedByMe // Solo mostrar icono de papelera en listas propias
                setCloseIconResource(R.drawable.ic_delete)
                setCloseIconTintResource(R.color.red_trash) // Color rojo para la papelera
                setEnsureMinTouchTargetSize(false)
                isSingleLine = true
                ellipsize = TextUtils.TruncateAt.END
                setPadding(32, 16, 32, 16)

                val isCurrentlySelected = currentListId == listId

                updateChipColors(this, isOwnedByMe, isSharedWithMe, isCurrentlySelected)
                isChecked = isCurrentlySelected

                // Click para seleccionar lista
                setOnClickListener {
                    if (currentListId != listId) {
                        binding.listsChipGroup.children.forEach { child ->
                            if (child is Chip && child.id != this.id) {
                                child.isChecked = false
                                val otherListId = child.tag as? String ?: return@forEach
                                val otherListPair = listsWithIds.find { it.first == otherListId }?.second ?: return@forEach
                                val otherCurrentUserEmail = auth.currentUser?.email ?: ""
                                val otherIsOwnedByMe = otherListPair.userId == auth.currentUser?.uid ||
                                        otherListPair.ownerEmail == otherCurrentUserEmail
                                val otherIsSharedWithMe = otherListPair.sharedWith.contains(otherCurrentUserEmail)

                                updateChipColors(child, otherIsOwnedByMe, otherIsSharedWithMe, false)
                            }
                        }

                        isChecked = true
                        updateChipColors(this, isOwnedByMe, isSharedWithMe, true)

                        currentListId = listId
                        loadItemsForList(listId)

                        loadListObservations(listId)
                        setupListObservationsListener(listId)

                        // Actualizar botones después de cambiar de lista
                        updateFABVisibility()
                        updateSplitExpensesButtonVisibility()

                        binding.itemsSectionLayout.visibility = View.VISIBLE
                    }
                }

                // Click en el icono de papelera para eliminar lista (solo en listas propias)
                setOnCloseIconClickListener {
                    if (isOwnedByMe) {
                        showDeleteListConfirmation(listId, text)
                    }
                }
            }
        }
    }

    // Diálogo de confirmación para eliminar lista
    private fun showDeleteListConfirmation(listId: String, listName: String) {
        AlertDialog.Builder(requireContext())
            .setTitle("Eliminar Lista")
            .setMessage("¿Eliminar la lista \"$listName\" y todos sus productos?\n\nEsta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                deleteList(listId)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // Función para eliminar lista y todos sus productos
    private fun deleteList(listId: String) {
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        // Verificar si el usuario es el propietario de la lista
        val currentList = listsWithIds.find { it.first == listId }?.second
        val isListOwnedByMe = currentList?.userId == userId || currentList?.ownerEmail == currentUserEmail

        if (!isListOwnedByMe) {
            showError("Solo el propietario puede eliminar la lista")
            return
        }

        val progressDialog = AlertDialog.Builder(requireContext())
            .setView(R.layout.dialog_loading)
            .setCancelable(false)
            .create()

        progressDialog.show()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                // 1. Primero eliminar todos los items
                val itemsQuery = db.collection("items")
                    .whereEqualTo("listId", listId)
                    .get()
                    .await()

                // Eliminar items en lotes (máximo 500 por batch)
                itemsQuery.documents.chunked(500).forEach { chunk ->
                    val chunkBatch = db.batch()
                    chunk.forEach { doc ->
                        chunkBatch.delete(db.collection("items").document(doc.id))
                    }
                    chunkBatch.commit().await()
                }

                // 2. Eliminar documentos relacionados
                val observationsRef = db.collection("listObservations").document(listId)
                val listRef = db.collection("lists").document(listId)

                // Verificar si existen antes de eliminar
                val observationsExists = observationsRef.get().await().exists()
                val listExists = listRef.get().await().exists()

                val finalBatch = db.batch()
                if (observationsExists) {
                    finalBatch.delete(observationsRef)
                }
                if (listExists) {
                    finalBatch.delete(listRef)
                }

                finalBatch.commit().await()

                withContext(Dispatchers.Main) {
                    progressDialog.dismiss()
                    showMessage("Lista eliminada exitosamente")

                    // Limpiar estado local
                    cleanupAfterListDeletion(listId)
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressDialog.dismiss()
                    showError("Error al eliminar la lista: ${e.message}")
                }
            }
        }
    }

    private fun cleanupAfterListDeletion(deletedListId: String) {
        // Limpiar observaciones
        listObservations.remove(deletedListId)

        // Si la lista eliminada era la actual, resetear la selección
        if (currentListId == deletedListId) {
            currentListId = null
            itemsAdapter.updateData(emptyList())
            listInfoSection.visibility = View.GONE
            binding.itemsSectionLayout.visibility = View.GONE
        }

        // Actualizar la UI
        updateListsDisplay()
    }

    // Actualizar colores del chip según tipo y estado
    private fun updateChipColors(chip: Chip, isOwnedByMe: Boolean, isSharedWithMe: Boolean, isSelected: Boolean) {
        if (isSelected) {
            val selectedColor = when (selectedListType) {
                ListType.MY_LISTS -> R.color.selected_my_list_color
                ListType.SHARED_LISTS -> R.color.selected_shared_list_color
            }

            chip.setChipBackgroundColorResource(selectedColor)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.selected_list_text_color))
            chip.chipStrokeWidth = 0f
        } else {
            when {
                isOwnedByMe -> {
                    chip.setChipBackgroundColorResource(R.color.chip_background_color)
                    chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.dark_blue))
                    chip.chipStrokeWidth = 1f
                    chip.setChipStrokeColorResource(R.color.chip_stroke_color)
                }
                isSharedWithMe -> {
                    chip.setChipBackgroundColorResource(R.color.shared_with_me_background)
                    chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.shared_with_me_text))
                    chip.chipStrokeWidth = 2f
                    chip.setChipStrokeColorResource(R.color.shared_with_me_stroke)
                }
                else -> {
                    chip.setChipBackgroundColorResource(R.color.shared_by_me_background)
                    chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.shared_by_me_text))
                    chip.chipStrokeWidth = 1f
                    chip.setChipStrokeColorResource(R.color.chip_stroke_color)
                }
            }
        }
    }

    // Configurar listeners de Firestore
    private fun setupFirestoreListeners() {
        val userId = auth.currentUser?.uid ?: run {
            if (isAdded) showError("Usuario no autenticado")
            return
        }

        val currentUserEmail = auth.currentUser?.email ?: ""

        listsListener?.remove()

        listsListener = db.collection("lists")
            .addSnapshotListener { snapshots, e ->
                if (!isAdded) return@addSnapshotListener
                if (e != null) {
                    return@addSnapshotListener
                }

                val allLists = snapshots?.documents?.mapNotNull { doc ->
                    val list = doc.toObject(ShoppingList::class.java)
                    if (list != null) doc.id to list else null
                } ?: emptyList()

                val relevantLists = allLists.filter { (_, list) ->
                    val isMyList = list.userId == userId || list.ownerEmail == currentUserEmail
                    val isSharedWithMe = list.sharedWith.contains(currentUserEmail)
                    isMyList || isSharedWithMe
                }

                updateListsUI(relevantLists)

                // Actualizar TODOS los botones después de procesar las listas
                updateFABVisibility()
                updateSplitExpensesButtonVisibility()
                updateShareButtonVisibility()
                updateCreateListButtonVisibility()
                updateFinalizePurchaseButtonVisibility()
                updateExtraInfoButtonVisibility()
                updateScanBarcodeButtonVisibility()
            }
    }

    private val listsWithIds = mutableListOf<Pair<String, ShoppingList>>()

    // Actualizar UI de listas
    private fun updateListsUI(allListPairs: List<Pair<String, ShoppingList>>) {
        if (!isAdded || context == null) return

        val previousSelectedListId = currentListId
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""
        val ownedLists = mutableListOf<Pair<String, ShoppingList>>()
        val sharedWithMeLists = mutableListOf<Pair<String, ShoppingList>>()

        allListPairs.forEach { pair ->
            val list = pair.second
            val isOwnedByMe = list.userId == userId || list.ownerEmail == currentUserEmail
            val isSharedWithMe = list.sharedWith.contains(currentUserEmail)

            if (isOwnedByMe) {
                ownedLists.add(pair)
            }

            if (isSharedWithMe && !isOwnedByMe) {
                sharedWithMeLists.add(pair)
            }
        }
        listsWithIds.clear()
        listsWithIds.addAll(ownedLists)
        listsWithIds.addAll(sharedWithMeLists)

        binding.listsChipGroup.removeAllViews()

        if (binding.listTypeSelectorChipGroup.childCount == 0) {
            addListTypeSelector()
        } else {
            updateSelectorChipColors()
        }

        // Garantizar selección de lista
        val validSelectedListId = if (previousSelectedListId != null &&
            listsWithIds.any { it.first == previousSelectedListId }) {
            previousSelectedListId
        } else if (listsWithIds.isNotEmpty()) {
            listsWithIds.first().first
        } else {
            null
        }

        showListsBySelectedType(ownedLists, sharedWithMeLists, validSelectedListId)

        currentListId = validSelectedListId

        if (currentListId != null) {
            loadItemsForList(currentListId!!)
            updateListSelectionInUI(currentListId!!)

            loadListObservations(currentListId!!)
            setupListObservationsListener(currentListId!!)
            setupPaymentListener(currentListId!!)

            binding.itemsSectionLayout.visibility = View.VISIBLE
        } else {
            binding.itemsSectionLayout.visibility = View.GONE
            listInfoListener?.remove()
        }

        updateFABVisibility()
        updateUIByListType()
        updateSplitExpensesButtonVisibility()
    }

    // Configurar UI principal
    private fun setupUI() {
        binding.logoutButton.setImageResource(R.drawable.ic_logout)
        binding.logoutButton.contentDescription = getString(R.string.logout)
        binding.logoutButton.setOnClickListener {
            auth.signOut()
            requireActivity().recreate()
        }

        binding.shareButton.setImageResource(R.drawable.ic_share)
        binding.shareButton.contentDescription = getString(R.string.share_list)
        binding.shareButton.setOnClickListener {
            showShareDialog()
        }

        updateShareButtonVisibility()
    }

    // Actualizar visibilidad del botón compartir
    private fun updateShareButtonVisibility() {
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        // Obtener las listas propias del usuario
        val ownedLists = listsWithIds.filter { pair ->
            val list = pair.second
            list.userId == userId || list.ownerEmail == currentUserEmail
        }

        // Mostrar botón compartir solo si estamos en "Mis Listas" y tenemos listas propias
        val shouldShowShareButton = selectedListType == ListType.MY_LISTS && ownedLists.isNotEmpty()

        binding.shareButton.visibility = if (shouldShowShareButton) View.VISIBLE else View.GONE
    }

    // Cargar items de la lista
    private fun loadItemsForList(listId: String) {
        itemsListener?.remove()
        itemsListener = db.collection("items")
            .whereEqualTo("listId", listId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    showError("Error al cargar productos: ${error.message}")
                    return@addSnapshotListener
                }

                val items = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        val item = doc.toObject(ShoppingItem::class.java)?.apply {
                            id = doc.id
                            if (category == null) {
                                category = determineCategory(text)
                            }
                            if (addedBy.isNullOrEmpty()) {
                                addedBy = ""
                            }
                            if (purchasedBy.isNullOrEmpty()) {
                                purchasedBy = ""
                            }
                        }
                        item
                    } catch (e: Exception) {
                        null
                    }
                } ?: emptyList()

                // Determinar si la lista actual es compartida
                val currentList = listsWithIds.find { it.first == listId }?.second
                val currentUserEmail = auth.currentUser?.email ?: ""
                val userId = auth.currentUser?.uid ?: ""

                val isListShared = currentList?.let { list ->
                    val isOwnedByMe = list.userId == userId || list.ownerEmail == currentUserEmail
                    val isSharedWithMe = list.sharedWith.contains(currentUserEmail)

                    // Es lista compartida si está compartida con otros o si me la han compartido
                    (isOwnedByMe && list.sharedWith.isNotEmpty()) || (isSharedWithMe && !isOwnedByMe)
                } ?: false

                // Pasar la información de si es lista compartida al adaptador
                itemsAdapter.updateData(items, true, isListShared)
            }
    }

    // Diálogo para compartir lista
    private fun showShareDialog() {
        val currentListId = currentListId ?: run {
            showError(getString(R.string.no_list_selected))
            return
        }

        val currentListPair = listsWithIds.find { it.first == currentListId }
        val currentList = currentListPair?.second
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        val isListOwnedByMe = currentList?.userId == userId || currentList?.ownerEmail == currentUserEmail
        val isListSharedWithMe = !isListOwnedByMe && currentList?.sharedWith?.contains(currentUserEmail) == true

        if (isListSharedWithMe) {
            showError("No puedes compartir una lista que te han compartido")
            return
        }

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_share_list, null)
        val emailEditText = dialogView.findViewById<EditText>(R.id.email_edit_text)
        val sharedUsersTextView = dialogView.findViewById<TextView>(R.id.shared_users_text_view)

        emailEditText.isFocusableInTouchMode = true
        emailEditText.setOnTouchListener { v, event ->
            v.requestFocus()
            false
        }

        db.collection("lists").document(currentListId).get()
            .addOnSuccessListener { document ->
                val updatedList = document.toObject(ShoppingList::class.java)
                val sharedWith = updatedList?.sharedWith ?: emptyList()

                if (sharedWith.isNotEmpty()) {
                    sharedUsersTextView.text = getString(R.string.shared_with) + "\n" +
                            sharedWith.joinToString("\n")
                    sharedUsersTextView.visibility = View.VISIBLE
                } else {
                    sharedUsersTextView.visibility = View.GONE
                }

                showShareDialogWithData(dialogView, currentListId, sharedWith)
            }
            .addOnFailureListener {
                showShareDialogWithData(dialogView, currentListId, currentList?.sharedWith ?: emptyList())
            }
    }

    // Mostrar diálogo de compartir con datos
    private fun showShareDialogWithData(dialogView: View, listId: String, sharedWith: List<String>) {
        val emailEditText = dialogView.findViewById<EditText>(R.id.email_edit_text)
        val sharedUsersTextView = dialogView.findViewById<TextView>(R.id.shared_users_text_view)

        emailEditText.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                emailEditText.postDelayed({
                    val inputMethodManager = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    inputMethodManager.showSoftInput(emailEditText, InputMethodManager.SHOW_IMPLICIT)
                }, 200)
            }
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.share_list_title))
            .setView(dialogView)
            .setPositiveButton(getString(R.string.share)) { _, _ ->
                val email = emailEditText.text.toString().trim()
                hideKeyboard(emailEditText)
                if (email.isNotEmpty()) {
                    if (email == auth.currentUser?.email) {
                        showError("No puedes compartir la lista contigo mismo")
                        return@setPositiveButton
                    }
                    shareList(listId, email)
                } else {
                    showError(getString(R.string.enter_email))
                }
            }
            .setNegativeButton(getString(R.string.cancel)) { _, _ ->
                hideKeyboard(emailEditText)
            }
            .setNeutralButton(getString(R.string.unshare)) { _, _ ->
                hideKeyboard(emailEditText)
                if (sharedWith.isNotEmpty()) {
                    showUnshareDialog(listId, sharedWith)
                } else {
                    showError("No hay usuarios para dejar de compartir")
                }
            }
            .setOnDismissListener {
                hideKeyboard(emailEditText)
            }
            .create()

        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        dialog.show()
    }

    // Diálogo para dejar de compartir
    private fun showUnshareDialog(listId: String, sharedEmails: List<String>) {
        if (sharedEmails.isEmpty()) {
            showError("No hay usuarios para dejar de compartir")
            return
        }

        val currentListPair = listsWithIds.find { it.first == listId }
        val currentList = currentListPair?.second
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        val isListOwnedByMe = currentList?.userId == userId || currentList?.ownerEmail == currentUserEmail

        if (!isListOwnedByMe) {
            showError("No tienes permisos para descompartir esta lista")
            return
        }

        val items = sharedEmails.toTypedArray()
        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.unshare_list_title))
            .setItems(items) { _, which ->
                val emailToRemove = items[which]
                unshareList(listId, emailToRemove)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // Compartir lista con usuario
    private fun shareList(listId: String, email: String) {
        val listRef = db.collection("lists").document(listId)
        val userRef = db.collection("users").document(email)

        val currentListPair = listsWithIds.find { it.first == listId }
        val currentList = currentListPair?.second
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        val isListOwnedByMe = currentList?.userId == userId || currentList?.ownerEmail == currentUserEmail

        if (!isListOwnedByMe) {
            showError("No tienes permisos para compartir esta lista")
            return
        }

        userRef.get().addOnSuccessListener { userSnapshot ->
            if (!userSnapshot.exists()) {
                showError("El usuario con email $email no existe en la aplicación")
                return@addOnSuccessListener
            }

            db.runTransaction { transaction ->
                val snapshot = transaction.get(listRef)
                val sharedWith = snapshot.get("sharedWith") as? MutableList<String> ?: mutableListOf()

                if (sharedWith.contains(email)) {
                    throw Exception("La lista ya está compartida con este usuario")
                }

                sharedWith.add(email)
                transaction.update(listRef, "sharedWith", sharedWith)
            }.addOnSuccessListener {
                showMessage("Lista compartida con $email")

                // Añadir automáticamente a la división de gastos
                addUserToPaymentSplit(listId, email)

                val dialogView = requireView().findViewById<EditText>(R.id.email_edit_text)
                dialogView?.text?.clear()
            }.addOnFailureListener { e ->
                showError("No se pudo compartir la lista: ${e.message}")
            }
        }.addOnFailureListener { e ->
            showError("Error al verificar el usuario: ${e.message}")
        }
    }

    // Añadir usuario a la división de gastos automáticamente
    // ✅ FUNCIÓN COMPLETAMENTE CORREGIDA: Añadir usuario a la división de gastos automáticamente
    private fun addUserToPaymentSplit(listId: String, email: String) {
        db.collection("listPayments").document(listId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    // El documento de pagos ya existe, actualizarlo
                    val paymentData = document.data ?: return@addOnSuccessListener

                    // ✅ CORRECCIÓN: Manejar tipos de forma segura
                    val currentParticipants = when (val participants = paymentData["paymentParticipants"]) {
                        is List<*> -> participants.mapNotNull { it as? Map<String, Any?> }
                        else -> emptyList()
                    }

                    // Verificar si el usuario ya está en la división
                    val isAlreadyInSplit = currentParticipants.any { participant ->
                        participant["email"] == email
                    }

                    if (!isAlreadyInSplit) {
                        // Añadir nuevo participante con tipos explícitos
                        val newParticipant = hashMapOf<String, Any?>(
                            "email" to email,
                            "name" to email.split("@")[0],
                            "userId" to null,
                            "isOwner" to false
                        )

                        // Crear nueva lista con tipos correctos
                        val updatedParticipants = ArrayList<Map<String, Any?>>(currentParticipants)
                        updatedParticipants.add(newParticipant)

                        // Actualizar en Firestore
                        db.collection("listPayments").document(listId)
                            .update("paymentParticipants", updatedParticipants)
                            .addOnSuccessListener {
                                showMessage("$email añadido automáticamente a la división de gastos")
                            }
                            .addOnFailureListener { e ->
                                showError("Error al añadir a división: ${e.message}")
                            }
                    }
                } else {
                    // El documento de pagos no existe, crear estructura inicial
                    createInitialPaymentDocument(listId, email)
                }
            }
            .addOnFailureListener { e ->
                showError("Error al acceder a división de gastos: ${e.message}")
            }
    }

    // ✅ FUNCIÓN AUXILIAR: Crear documento inicial de pagos
    private fun createInitialPaymentDocument(listId: String, newUserEmail: String) {
        val currentList = listsWithIds.find { it.first == listId }?.second
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        val initialParticipants = ArrayList<Map<String, Any?>>()

        // Añadir propietario
        initialParticipants.add(hashMapOf(
            "email" to currentUserEmail,
            "name" to currentUserEmail.split("@")[0],
            "userId" to userId,
            "isOwner" to true
        ))

        // Añadir usuario compartido
        initialParticipants.add(hashMapOf(
            "email" to newUserEmail,
            "name" to newUserEmail.split("@")[0],
            "userId" to null,
            "isOwner" to false
        ))

        // Crear documento de pagos
        val paymentData = hashMapOf<String, Any>(
            "listId" to listId,
            "listName" to (currentList?.name ?: "Lista sin nombre"),
            "paymentParticipants" to initialParticipants,
            "payments" to hashMapOf<String, Any>(),
            "updatedAt" to com.google.firebase.Timestamp.now(),
            "updatedBy" to currentUserEmail
        )

        db.collection("listPayments").document(listId)
            .set(paymentData)
            .addOnSuccessListener {
                showMessage("División de gastos creada automáticamente")
            }
            .addOnFailureListener { e ->
                showError("Error al crear división: ${e.message}")
            }
    }

    // Dejar de compartir lista
    private fun unshareList(listId: String, email: String) {
        val currentListPair = listsWithIds.find { it.first == listId }
        val currentList = currentListPair?.second
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        val isListOwnedByMe = currentList?.userId == userId || currentList?.ownerEmail == currentUserEmail

        if (!isListOwnedByMe) {
            showError("No tienes permisos para descompartir esta lista")
            return
        }

        db.collection("lists").document(listId)
            .update("sharedWith", FieldValue.arrayRemove(email))
            .addOnSuccessListener {
                showMessage("Dejado de compartir con $email")

                // Eliminar automáticamente de la división de gastos
                removeUserFromPaymentSplit(listId, email)
            }
            .addOnFailureListener { e ->
                showError("Error al dejar de compartir: ${e.message}")
            }
    }

    // Eliminar usuario de la división de gastos
    private fun removeUserFromPaymentSplit(listId: String, email: String) {
        db.collection("listPayments").document(listId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val paymentData = document.data ?: return@addOnSuccessListener
                    val currentParticipants = paymentData["paymentParticipants"] as? List<Map<String, Any>> ?: emptyList()

                    // Filtrar el usuario eliminado
                    val updatedParticipants = currentParticipants.filterNot { it["email"] == email }

                    // Eliminar también sus pagos
                    val currentPayments = paymentData["payments"] as? Map<String, Map<String, Any>> ?: emptyMap()
                    val updatedPayments = currentPayments.toMutableMap().apply {
                        remove(email)
                    }

                    // Actualizar en Firestore
                    db.collection("listPayments").document(listId)
                        .update(
                            "paymentParticipants", updatedParticipants,
                            "payments", updatedPayments
                        )
                        .addOnSuccessListener {
                            showMessage("$email eliminado de la división de gastos")
                            // Actualizar la visualización
                            currentListId?.let { loadItemsForList(it) }
                        }
                }
            }
    }

    // Crear nueva lista
    private fun createList(name: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val user = auth.currentUser ?: return@launch
                val list = ShoppingList(
                    name = name,
                    userId = user.uid,
                    ownerEmail = user.email ?: "",
                    createdAt = com.google.firebase.Timestamp.now()
                )

                val documentReference = db.collection("lists").add(list).await()
                val newListId = documentReference.id

                withContext(Dispatchers.Main) {
                    showMessage("Lista creada: $name")

                    currentListId = newListId
                    setupFirestoreListeners()
                    loadItemsForList(newListId)

                    loadListObservations(newListId)
                    setupListObservationsListener(newListId)

                    updateFABVisibility()

                    binding.itemsSectionLayout.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showError("Error al crear lista: ${e.message}")
                }
            }
        }
    }

    // Diálogo de confirmación para eliminar item
    private fun showDeleteConfirmation(item: ShoppingItem) {
        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.delete_item_title))
            .setMessage(getString(R.string.delete_item_message, item.text))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                deleteItem(item)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // Actualizar visibilidad del botón crear lista
    private fun updateCreateListButtonVisibility() {
        val shouldShowCreateListButton = selectedListType == ListType.MY_LISTS

        if (::binding.isInitialized) {
            binding.createListCard.visibility = if (shouldShowCreateListButton) View.VISIBLE else View.GONE
        }
    }

    // Configurar UI elegante
    private fun setupElegantUI() {
        try {
            binding.createListCard.setOnClickListener {
                if (selectedListType == ListType.MY_LISTS) {
                    showCreateListDialog()
                }
            }
        } catch (e: Exception) {
        }

        try {
            binding.fabAddProduct?.setOnClickListener {
                showAddProductDialog()
            }
        } catch (e: Exception) {
        }
    }

    private fun updateFinalizePurchaseButtonVisibility() {
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        // Obtener las listas relevantes según el tipo seleccionado
        val relevantLists = when (selectedListType) {
            ListType.MY_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.userId == userId || list.ownerEmail == currentUserEmail
            }
            ListType.SHARED_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.sharedWith.contains(currentUserEmail) &&
                        !(list.userId == userId || list.ownerEmail == currentUserEmail)
            }
        }

        val hasRelevantLists = relevantLists.isNotEmpty()
        val hasListSelected = currentListId != null && relevantLists.any { it.first == currentListId }

        // Mostrar botón solo si hay listas relevantes y hay una lista seleccionada
        binding.finalizePurchaseButton.visibility = if (hasRelevantLists && hasListSelected) View.VISIBLE else View.GONE
    }

    private fun updateExtraInfoButtonVisibility() {
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        // Obtener las listas relevantes según el tipo seleccionado
        val relevantLists = when (selectedListType) {
            ListType.MY_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.userId == userId || list.ownerEmail == currentUserEmail
            }
            ListType.SHARED_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.sharedWith.contains(currentUserEmail) &&
                        !(list.userId == userId || list.ownerEmail == currentUserEmail)
            }
        }

        val hasRelevantLists = relevantLists.isNotEmpty()
        val hasListSelected = currentListId != null && relevantLists.any { it.first == currentListId }

        // Mostrar botón solo si hay listas relevantes y hay una lista seleccionada
        binding.addExtraInfoButton.visibility = if (hasRelevantLists && hasListSelected) View.VISIBLE else View.GONE
    }

    private fun updateScanBarcodeButtonVisibility() {
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        // Obtener las listas relevantes según el tipo seleccionado
        val relevantLists = when (selectedListType) {
            ListType.MY_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.userId == userId || list.ownerEmail == currentUserEmail
            }
            ListType.SHARED_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.sharedWith.contains(currentUserEmail) &&
                        !(list.userId == userId || list.ownerEmail == currentUserEmail)
            }
        }

        val hasRelevantLists = relevantLists.isNotEmpty()
        val hasListSelected = currentListId != null && relevantLists.any { it.first == currentListId }

        // Mostrar botón solo si hay listas relevantes y hay una lista seleccionada
        binding.scanBarcodeButton.visibility = if (hasRelevantLists && hasListSelected) View.VISIBLE else View.GONE
    }

    // Diálogo para crear lista
    private fun showCreateListDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_create_list, null)
        val listNameEditText = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.list_name_edit_text)
        val createButton = dialogView.findViewById<com.google.android.material.button.MaterialButton>(R.id.create_list_dialog_button)
        val cancelButton = dialogView.findViewById<com.google.android.material.button.MaterialButton>(R.id.cancel_button)

        val dialog = AlertDialog.Builder(requireContext(), R.style.CustomDialogTheme)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        // Configurar el comportamiento del teclado
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)

        dialog.window?.setBackgroundDrawableResource(android.R.color.white)

        // Variable para controlar si el teclado debe ocultarse
        var shouldHideKeyboard = true

        // Listener para cuando el diálogo se cierra
        dialog.setOnDismissListener {
            if (shouldHideKeyboard) {
                hideKeyboard(listNameEditText)
            }
        }

        // Listener para cuando se cancela el diálogo
        dialog.setOnCancelListener {
            if (shouldHideKeyboard) {
                hideKeyboard(listNameEditText)
            }
        }

        // Configurar el comportamiento cuando se toca fuera del diálogo
        dialog.setCanceledOnTouchOutside(true)

        // Obtener la ventana del diálogo y configurar el listener de toque
        dialog.window?.decorView?.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                // Ocultar el teclado inmediatamente cuando se toca fuera
                hideKeyboard(listNameEditText)
            }
            false // Dejar que el sistema maneje el toque normalmente
        }

        createButton.setOnClickListener {
            val listName = listNameEditText.text.toString().trim()
            if (listName.isNotEmpty()) {
                shouldHideKeyboard = false // No ocultar teclado porque estamos procesando
                hideKeyboard(listNameEditText)
                createList(listName)
                dialog.dismiss()
            } else {
                listNameEditText.error = "Ingresa un nombre para la lista"
                // Mantener el teclado visible para que el usuario pueda escribir
                listNameEditText.requestFocus()
            }
        }

        cancelButton.setOnClickListener {
            shouldHideKeyboard = false // No ocultar teclado porque estamos procesando
            hideKeyboard(listNameEditText)
            dialog.dismiss()
        }

        dialog.show()

        // Enfocar y mostrar teclado después de que el diálogo esté visible
        listNameEditText.postDelayed({
            listNameEditText.requestFocus()
            val inputMethodManager = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.showSoftInput(listNameEditText, InputMethodManager.SHOW_IMPLICIT)
        }, 200)
    }

    // Diálogo para añadir producto
    private fun showAddProductDialog() {
        val currentListId = currentListId ?: run {
            showError("Selecciona una lista primero")
            return
        }

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_product, null)
        val productNameEditText = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.product_name_edit_text)
        val addButton = dialogView.findViewById<com.google.android.material.button.MaterialButton>(R.id.add_product_dialog_button)
        val cancelButton = dialogView.findViewById<com.google.android.material.button.MaterialButton>(R.id.cancel_button)

        val dialog = AlertDialog.Builder(requireContext(), R.style.CustomDialogTheme)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        // IMPORTANTE: Configurar para manejar correctamente el teclado
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)

        // Listener para cuando el diálogo se cierra
        dialog.setOnDismissListener {
            hideKeyboard(productNameEditText)
        }

        // Listener para cuando se cancela el diálogo
        dialog.setOnCancelListener {
            hideKeyboard(productNameEditText)
        }

        // Listener para cuando se toca fuera del diálogo
        dialog.setOnShowListener {
            // Obtener la vista del diálogo y configurar el click listener
            val window = dialog.window
            val decorView = window?.decorView

            decorView?.setOnTouchListener { _, event ->
                // Si se toca fuera del contenido del diálogo
                if (event.action == MotionEvent.ACTION_DOWN) {
                    val x = event.x
                    val y = event.y

                    // Obtener el área del contenido del diálogo
                    val contentView = dialog.findViewById<View>(android.R.id.content)
                    contentView?.let { content ->
                        val contentRect = Rect()
                        content.getGlobalVisibleRect(contentRect)

                        // Si el toque está fuera del área del contenido
                        if (!contentRect.contains(x.toInt(), y.toInt())) {
                            hideKeyboard(productNameEditText)
                            // No llamamos dismiss() aquí para permitir que el usuario
                            // cancele tocando fuera si así lo desea
                        }
                    }
                }
                false
            }
        }

        addButton.setOnClickListener {
            val productName = productNameEditText.text.toString().trim()
            if (productName.isNotEmpty()) {
                hideKeyboard(productNameEditText)
                addItem(productName)
                dialog.dismiss()
            } else {
                productNameEditText.error = "Ingresa el nombre del producto"
            }
        }

        cancelButton.setOnClickListener {
            hideKeyboard(productNameEditText)
            dialog.dismiss()
        }

        dialog.show()

        // Enfocar y mostrar teclado después de que el diálogo esté visible
        productNameEditText.postDelayed({
            productNameEditText.requestFocus()
            val inputMethodManager = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.showSoftInput(productNameEditText, InputMethodManager.SHOW_IMPLICIT)
        }, 200)
    }

    // Actualizar visibilidad del FAB
    private fun updateFABVisibility() {
        val currentUserEmail = auth.currentUser?.email ?: ""
        val userId = auth.currentUser?.uid ?: ""

        // Obtener las listas según el tipo seleccionado
        val relevantLists = when (selectedListType) {
            ListType.MY_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.userId == userId || list.ownerEmail == currentUserEmail
            }
            ListType.SHARED_LISTS -> listsWithIds.filter { pair ->
                val list = pair.second
                list.sharedWith.contains(currentUserEmail) &&
                        !(list.userId == userId || list.ownerEmail == currentUserEmail)
            }
        }

        val hasRelevantLists = relevantLists.isNotEmpty()
        val hasListSelected = currentListId != null && relevantLists.any { it.first == currentListId }

        if (::binding.isInitialized) {
            // Mostrar FAB solo si hay listas relevantes para el tipo seleccionado y hay una lista seleccionada
            binding.fabAddProduct.visibility = if (hasRelevantLists && hasListSelected) View.VISIBLE else View.GONE
        }
    }

    // Eliminar item
    private fun deleteItem(item: ShoppingItem) {
        db.collection("items")
            .whereEqualTo("text", item.text)
            .whereEqualTo("listId", item.listId)
            .whereEqualTo("createdAt", item.createdAt)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val document = querySnapshot.documents[0]
                    val itemId = document.id

                    document.reference.delete()
                        .addOnSuccessListener {
                            showMessage(getString(R.string.item_deleted))
                            currentListId?.let { loadItemsForList(it) }
                        }
                        .addOnFailureListener {
                            showError(getString(R.string.delete_error))
                        }
                }
            }
            .addOnFailureListener {
                showError("Error al intentar eliminar el producto")
            }
    }

    // Mostrar mensaje de error
    private fun showError(message: String) {
        try {
            if (isAdded && view != null) {
                activity?.runOnUiThread {
                    Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG)
                        .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.error_red))
                        .setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                        .show()
                }
            } else {
            }
        } catch (e: Exception) {
        }
    }

    // Mostrar mensaje informativo
    private fun showMessage(message: String) {
        try {
            if (isAdded && view != null) {
                activity?.runOnUiThread {
                    Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT).show()
                }
            } else {
            }
        } catch (e: Exception) {
        }
    }

    // Ocultar teclado
    private fun hideKeyboard(view: View) {
        try {
            val inputMethodManager = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)

            // También perder el foco para asegurar que el teclado se cierre
            view.clearFocus()

            // Opcional: Ocultar teclado de forma global si es necesario
            val activity = requireActivity()
            val currentFocus = activity.currentFocus
            currentFocus?.let {
                inputMethodManager.hideSoftInputFromWindow(it.windowToken, 0)
            }
        } catch (e: Exception) {
            // Ignorar errores al ocultar el teclado
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        itemsListener?.remove()
        listsListener?.remove()
        listInfoListener?.remove()
    }

    // Palabras clave para categorización de productos
    private val categoryKeywords = mapOf(
        ProductCategory.FRUITS_VEGETABLES to listOf(
            "manzana", "plátano", "naranja", "pera", "kiwi", "melón", "sandía", "piña", "fresa", "mango",
            "papaya", "coco", "granada", "lima", "limón", "mandarina", "frambuesa", "arándanos", "moras",
            "cereza", "ciruela", "higo", "melocotón", "nectarina", "albaricoque", "lichi", "guayaba",
            "maracuyá", "durazno", "tamarindo", "caqui", "pera conferencia", "pera asiática",
            "lechuga", "tomate", "zanahoria", "cebolla", "pimiento", "espinaca", "brócoli", "coliflor",
            "ajo", "pepino", "calabacín", "berenjena", "aguacate", "rábano", "alcachofa", "apio",
            "remolacha", "calabaza", "endivia", "setas", "coles de bruselas", "judías verdes", "hinojo",
            "nabo", "escarola", "col", "repollo", "kale", "guisantes", "boniato", "batata", "yuca",
            "okra", "puerro", "chalota", "cogollo", "rúcula", "berros", "mizuna", "pak choi", "edamame",
            "fruta", "verdura", "hortaliza", "ensalada", "alcachofas", "espárragos", "acelgas", "canónigos",
            "hacendado", "dia", "carrefour", "eroski", "alcampo", "mercadona", "bonpreu", "condis"
        ),
        ProductCategory.MEAT to listOf(
            "pollo", "ternera", "cerdo", "pavo", "cordero", "chuleta", "filete", "salchicha", "jamón",
            "bacon", "costilla", "albóndigas", "chorizo", "morcilla", "lomo", "hamburguesa", "foie",
            "pato", "conejo", "caballo", "solomillo", "entrecot", "falda", "secreto ibérico",
            "presa ibérica", "paletilla", "butifarra", "longaniza", "salami", "mortadela", "pastrami",
            "pepperoni", "prosciutto", "carne", "panceta", "salchichón", "fiambre", "embutido",
            "hacendado", "dia", "carrefour", "alcampo", "eroski", "elpozo", "campofrío", "revilla",
            "sánchez alcaraz", "coren", "casa tarradellas", "la piara", "ibéricos", "cárnico"
        ),
        ProductCategory.DAIRY to listOf(
            "leche", "queso", "yogur", "mantequilla", "nata", "crema", "queso crema", "leche condensada",
            "leche evaporada", "requesón", "kefir", "batido de leche", "provolone", "mozzarella",
            "parmesano", "queso azul", "brie", "camembert", "emmental", "gouda", "cheddar",
            "queso rallado", "queso curado", "queso semicurado", "queso fresco", "leche sin lactosa",
            "leche de cabra", "leche de oveja", "margarina", "yoghurt", "cuajada", "flan", "natillas",
            "lácteo", "láctea", "hacendado", "dia", "carrefour", "alcampo", "eroski", "asturiana",
            "pascual", "lauki", "ram", "central lechera", "nestlé", "danone", "actimel", "activia",
            "danet", "petit suisse", "philadelphia", "tulipán", "flora", "lactalis", "president",
            "villagodio", "arroyo", "el pastor", "cambridge", "kaiku", "covap", "pler", "capsa", "llet"
        ),
        ProductCategory.BAKERY to listOf(
            "pan", "bollo", "baguette", "tostada", "croissant", "galleta", "magdalena", "bizcocho",
            "donut", "empanada", "pan integral", "pan de molde", "rosquilla", "tarta", "ensaimada",
            "pan de centeno", "pan de cereales", "pan sin gluten", "picos", "regañás", "muffin",
            "cruasán", "eclair", "brownie", "pastel", "pastelería", "bollería", "repostería",
            "hacendado", "dia", "carrefour", "alcampo", "eroski", "bimbo", "ortiz", "fontaneda",
            "gullón", "cuétara", "artiach", "maría", "dorada", "tosta rica", "bimbo", "panrico",
            "donuts", "lidl", "bon area", "silueta", "mollete", "chapata", "hogaza", "pasta", "masa"
        ),
        ProductCategory.CLEANING to listOf(
            "jabón", "detergente", "limpiador", "lejía", "esponja", "papel higiénico", "limpiacristales",
            "lavavajillas", "suavizante", "desinfectante", "guantes", "fregasuelos", "bayeta",
            "ambientador", "quitamanchas", "toallitas limpiadoras", "cepillo", "escoba", "recogedor",
            "mopa", "cera para suelo", "limpiador multiusos", "insecticida", "limpia", "detergente",
            "limpieza", "higiene", "hacendado", "dia", "carrefour", "alcampo", "eroski", "deliplus",
            "mascleans", "don simón", "cinco estrellas", "ajax", "estrella", "w5", "wipp", "mimosín",
            "fairy", "mistol", "kip", "lysoform", "bayclin", "sanytol", "hogar", "cif", "don limpio",
            "vim", "acme", "scotch brite", "tena", "sc johnson", "colhogar", "reny", "scottex", "foxy"
        ),
        ProductCategory.BEVERAGES to listOf(
            "agua", "refresco", "zumo", "jugo", "cerveza", "vino", "café", "té", "bebida energética",
            "batido", "licor", "kombucha", "agua con gas", "horchata", "infusión", "ron", "whisky",
            "ginebra", "vodka", "champán", "cava", "vermú", "sidra", "anís", "tequila", "mezcal",
            "sake", "mocktail", "agua saborizada", "cola", "fanta", "sprite", "nestea", "aquarius",
            "trina", "schweppes", "pepsi", "cocacola", "red bull", "monster", "burn", "nesquik",
            "cola cao", "colacao", "cacao", "chocolate", "chocolatada", "bebida", "energy", "energética",
            "isotónica", "gaseosa", "limonada", "granizado", "smoothie", "zumo de naranja", "zumo de manzana",
            "font bella", "fontvella", "solán", "bezoya", "lanjarón", "evian", "volvic", "vichy", "font natura",
            "beefeater", "hacendado", "dia", "carrefour", "alcampo", "eroski", "bonpreu", "casera",
            "la casera", "gaseosa", "sidra el gaitero", "mahou", "san miguel", "estrella galicia", "cruzcampo",
            "heineken", "amstel", "bacardi", "smirnoff", "absolut", "ballantine's", "jose cuervo", "baileys",
            "martini", "campari", "fernet", "café carrefour", "café marcilla", "café sello", "nescafé",
            "bonka", "saimaza", "té poms", "té twinings", "té hornimans", "té lipton", "hacendado", "dia"
        ),
        ProductCategory.CONGELADOS to listOf(
            "helado", "pizza", "verduras congeladas", "pescado congelado", "croquetas", "nuggets",
            "empanadillas", "lasaña congelada", "tarta helada", "pan congelado", "marisco congelado",
            "fruta congelada", "patatas fritas congeladas", "aritos de cebolla", "gofres congelados",
            "congelado", "congelada", "ultracongelado", "ultracongelada", "frozen", "hacendado",
            "dia", "carrefour", "alcampo", "eroski", "findus", "la cocina", "maheso", "casa tarradellas",
            "pescanova", "frigo", "calipo", "magnum", "cornetto", "nestlé", "miko", "carte d'or",
            "ovonature", "bon area", "dr oetker", "bagel", "pizza casa di mama", "pizza buratina"
        ),
        ProductCategory.SNACKS to listOf(
            "patatas fritas", "gusanitos", "palomitas", "barritas energéticas", "galletas saladas",
            "chocolate", "caramelos", "chicles", "turrón", "bombones", "frutos secos", "torreznos",
            "barquillos", "rosquillas", "nachos", "crackers", "palitos de pan", "regaliz", "mix trail",
            "chips vegetales", "snacks de arroz", "snacks de maíz", "snack", "aperitivo", "pipas",
            "cacahuetes", "almendras", "nueces", "avellanas", "golosina", "chuchería", "hacendado",
            "dia", "carrefour", "alcampo", "eroski", "lays", "matutano", "snatt's", "ruffles", "doritos",
            "cheetos", "fritos", "takis", "orbit", "trident", "chicles", "mentos", "gominolas", "haribo",
            "fini", "tableta", "kit kat", "ferrero rocher", "kinder", "milka", "lindt", "toblerone",
            "nestlé", "valor", "lacasa", "turon", "el almendro", "picos", "regaliz", "girabolas"
        ),
        ProductCategory.CANNED to listOf(
            "atún en lata", "maíz en lata", "sardinas", "tomate triturado", "alubias en conserva",
            "garbanzos en lata", "pimientos asados", "olivas", "fruta en almíbar", "paté",
            "judías en conserva", "sopa en lata", "mejillones en escabeche", "berberechos",
            "caballa en lata", "anchoas", "pulpo en conserva", "conserva", "enlatado", "enlatada",
            "hacendado", "dia", "carrefour", "alcampo", "eroski", "calvo", "cuca", "isabel", "campsa",
            "frinsa", "jealsa", "carlos", "ortiz", "bonito", "atún claro", "atún claro", "aceitunas",
            "la española", "arbonia", "albo", "gustavo", "fabada", "cocido", "lentejas", "garbanzos",
            "callos", "salmorejo", "gazpacho", "bon area", "alcampo", "dia", "hacendado"
        ),
        ProductCategory.GRAINS_PASTA to listOf(
            "arroz", "pasta", "espaguetis", "macarrones", "quinoa", "cuscús", "harina", "sémola",
            "copos de avena", "pan rallado", "fideos", "lentejas", "garbanzos secos", "soja",
            "trigo sarraceno", "mijo", "bulgur", "polenta", "arroz integral", "arroz basmati",
            "arroz jazmín", "tallarines", "ramen", "udon", "legumbre", "cereal", "granos",
            "hacendado", "dia", "carrefour", "alcampo", "eroski", "gallo", "costa", "buitoni",
            "barilla", "de cecco", "spaghetti", "fusilli", "penne", "lasaña", "canelones", "tallarines",
            "arroz bomba", "arroz redondo", "arroz largo", "lentejas pardinas", "garbanzos pedrosillano",
            "alubias", "judías", "habas", "guisantes", "avena", "trigo", "centeno", "cebada", "muesli",
            "copos", "cereales", "all bran", "chocapic", "frosties", "special k", "corn flakes"
        ),
        ProductCategory.SAUCES_SPICES to listOf(
            "sal", "azúcar", "pimienta", "orégano", "vinagre", "aceite de oliva", "aceite de girasol",
            "salsa de tomate", "mayonesa", "ketchup", "mostaza", "salsa barbacoa", "caldo concentrado",
            "curry", "canela", "pimentón", "nuez moscada", "albahaca", "perejil", "comino", "soja",
            "wasabi", "tabasco", "salsa picante", "salsa agridulce", "garam masala", "jengibre",
            "clavo", "cúrcuma", "cilantro", "salsa", "condimento", "especia", "aliño", "aderezo",
            "hacendado", "dia", "carrefour", "alcampo", "eroski", "hellmann's", "heinz", "kikkoman",
            "tabasco", "sriracha", "valentina", "salsa rosa", "salsa brava", "salsa carbonara",
            "salsa boloñesa", "salsa pesto", "salsa teriyaki", "salsa soja", "aceite carbonell",
            "aceite coosur", "aceite la española", "aceite hojiblanca", "vinagre madre", "sal costa",
            "sal maldon", "pimienta negra", "azúcar azucarera", "azúcar terrapal", "royal", "levadura",
            "bicarbonato", "maicena", "gelatina", "cuajada", "colorante", "vainilla", "canela molida"
        ),
        ProductCategory.PERSONAL_CARE to listOf(
            "champú", "gel de baño", "desodorante", "pasta de dientes", "cepillo de dientes",
            "maquinilla de afeitar", "cuchillas", "papel higiénico", "pañuelos", "toallitas",
            "colonia", "crema hidratante", "protector solar", "aftershave", "jabón de manos",
            "loción corporal", "acondicionador", "cepillo para el pelo", "mascarilla facial",
            "cosmético", "higiene", "cuidado", "aseo", "hacendado", "dia", "carrefour", "alcampo",
            "eroski", "delipius", "deliplus", "garnier", "l'oreal", "nivea", "dove", "rexona",
            "axe", "head & shoulders", "pantene", "colgate", "oral b", "signal", "sensodyne",
            "lysopine", "gillette", "schick", "wilkinson", "after shave", "loción", "crema",
            "hidratante", "protector", "bronceador", "jabón", "gel", "espuma", "shampoo", "acondicionador",
            "mascarilla", "exfoliante", "tónico", "contorno", "serum", "maquillaje", "base", "polvo",
            "colorete", "sombra", "rimel", "labial", "esmalte", "perfume", "fragancia", "desodorante"
        ),
        ProductCategory.PET to listOf(
            "comida para perros", "comida para gatos", "arena para gatos", "huesos",
            "snacks para mascotas", "juguetes para mascotas", "collar", "champú para mascotas",
            "camas para mascotas", "correa", "rascador", "pienso", "comida húmeda", "transportín",
            "comedero", "bebedero", "mascota", "animal", "perro", "gato", "hacendado", "dia",
            "carrefour", "alcampo", "eroski", "ultima", "advance", "purina", "royal canin", "hills",
            "acana", "orijen", "taste of the wild", "pienso", "latas", "sobres", "snacks", "galletas",
            "premios", "juguete", "pelota", "mordedor", "rascador", "cepillo", "champú", "antiparasitario",
            "pipeta", "collarin", "arena", "absorbente", "lecho", "cama", "almohada", "transportín",
            "correa", "arnés", "comedero", "bebedero", "accesorio", "mascota"
        ),
        ProductCategory.BABY to listOf(
            "pañales", "toallitas húmedas", "papilla", "leche infantil", "biberones",
            "crema para bebés", "chupete", "cuna portátil", "potito", "babero", "andador",
            "sonajero", "mantita", "silla de paseo", "bebé", "infantil", "niño", "niña",
            "hacendado", "dia", "carrefour", "alcampo", "eroski", "dodot", "pampers", "huggies",
            "babysec", "dodot", "toallitas", "papilla", "nestlé", "nutribén", "almiron", "blemil",
            "sanutri", "potito", "hero baby", "hipp", "biberón", "avent", "nuk", "suavinex",
            "chupete", "dodie", "canpol", "babero", "body", "pijama", "crema", "mustela", "isdin",
            "leti", "hidratante", "protector", "pañal", "toallita", "cuna", "minicuna", "hamaca",
            "trona", "silla", "cochecito", "carrito", "andador", "correpasillos", "juguete", "sonajero",
            "mordedor", "peluche", "muñeco", "educativo"
        ),
        ProductCategory.OTHER to listOf(
            "pilas", "velas", "encendedor", "bolsas de basura", "revista", "cuaderno", "bombilla",
            "linterna", "cinta adhesiva", "tijeras", "pegamento", "clips", "bolígrafos", "lápices",
            "gomas de borrar", "sacapuntas", "carpeta", "grapadora", "cargador", "alargador",
            "hacendado", "dia", "carrefour", "alcampo", "eroski", "duracell", "energizer", "varta",
            "panasonic", "vela", "cerilla", "encendedor", "clipper", "cricket", "bolsa", "saco",
            "basura", "residuo", "revista", "periódico", "libro", "cuaderno", "oxford", "bic",
            "pilot", "staedtler", "faber castell", "post it", "tipp ex", "celo", "scotch", "fixo",
            "pritt", "super glue", "clip", "grapa", "tacker", "carpeta", "archivador", "sobre",
            "bombilla", "led", "halógena", "fluorescente", "linterna", "frontal", "cargador",
            "usb", "cable", "adaptador", "alargador", "regleta", "enchufe", "ladrón"
        )
    )

    private fun determineCategory(itemText: String): ProductCategory {
        if (itemText.startsWith("[COMPLETADO]")) {
            return ProductCategory.COMPRADO
        }

        val normalizedText = itemText.lowercase().trim()

        // PRIMERO: Buscar palabras clave específicas en TODO el texto
        val categoryMatches = mutableMapOf<ProductCategory, Int>()

        // Buscar en todo el texto, no solo en la primera palabra
        categoryKeywords.forEach { (category, keywords) ->
            var matches = 0
            keywords.forEach { keyword ->
                // Buscar la palabra clave como palabra completa (no subcadena)
                if (normalizedText.contains("\\b$keyword\\b".toRegex())) {
                    matches++
                }
            }
            if (matches > 0) {
                categoryMatches[category] = matches
            }
        }

        // Si encontramos coincidencias, devolver la categoría con más matches
        if (categoryMatches.isNotEmpty()) {
            return categoryMatches.maxByOrNull { it.value }?.key ?: ProductCategory.OTHER
        }

        // SEGUNDO: Si no hay coincidencias exactas, buscar por patrones específicos
        return when {
            // Bebidas
            normalizedText.contains("\\b(agua|cola|refresco|zumo|jugo|cerveza|vino|café|té|bebida|energy|energética|infusión|horchata|gaseosa|limonada|batido)\\b".toRegex())
                -> ProductCategory.BEVERAGES

            // Lácteos y margarina
            normalizedText.contains("\\b(margarina|mantequilla|leche|yogur|queso|nata|crema|yoghurt|requesón|kefir|cuajada)\\b".toRegex())
                -> ProductCategory.DAIRY

            // Cola Cao y productos similares
            normalizedText.contains("\\b(cola cao|cacao|chocolate|nesquik|colacao|chocolatada)\\b".toRegex())
                -> ProductCategory.BEVERAGES

            // Productos de panadería
            normalizedText.contains("\\b(pan|bollo|baguette|tostada|croissant|galleta|magdalena|bizcocho|donut|empanada|rosquilla|tarta|ensaimada|muffin|cruasán|brownie)\\b".toRegex())
                -> ProductCategory.BAKERY

            // Frutas y verduras
            normalizedText.contains("\\b(manzana|plátano|naranja|pera|kiwi|melón|sandía|piña|fresa|mango|lechuga|tomate|zanahoria|cebolla|pimiento|espinaca|brócoli|coliflor|ajo|pepino|calabacín|berenjena|aguacate)\\b".toRegex())
                -> ProductCategory.FRUITS_VEGETABLES

            // Carnes
            normalizedText.contains("\\b(pollo|ternera|cerdo|pavo|cordero|chuleta|filete|salchicha|jamón|bacon|costilla|albóndigas|chorizo|morcilla|lomo|hamburguesa)\\b".toRegex())
                -> ProductCategory.MEAT

            // Lácteos (más específico)
            normalizedText.contains("\\b(leche|yogur|queso|mantequilla|nata|yoghurt)\\b".toRegex())
                -> ProductCategory.DAIRY

            // Congelados
            normalizedText.contains("\\b(helado|pizza|congelado|congelada|croquetas|nuggets|empanadillas|lasaña|tarta helada)\\b".toRegex())
                -> ProductCategory.CONGELADOS

            // Snacks
            normalizedText.contains("\\b(patatas fritas|gusanitos|palomitas|barritas|chocolate|caramelos|chicles|turrón|bombones|frutos secos|snack|aperitivo)\\b".toRegex())
                -> ProductCategory.SNACKS

            // Limpieza
            normalizedText.contains("\\b(jabón|detergente|limpiador|lejía|esponja|papel higiénico|lavavajillas|suavizante|desinfectante|ambientador|quitamanchas)\\b".toRegex())
                -> ProductCategory.CLEANING

            // Cuidado personal
            normalizedText.contains("\\b(champú|gel|desodorante|pasta de dientes|cepillo|maquinilla|colonia|crema|protector solar|jabón de manos|acondicionador)\\b".toRegex())
                -> ProductCategory.PERSONAL_CARE

            else -> ProductCategory.OTHER
        }
    }
}